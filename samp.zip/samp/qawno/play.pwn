#include <a_samp>
#include <dini>

// 每秒计时
new g_PlayerSec[MAX_PLAYERS];

public OnGameModeInit()
{
    SetTimer("Timer_MinuteScore", 1000, true);
    return 1;
}

// 进入服务器：读取原生Score
public OnPlayerConnect(playerid)
{
    new path[128], name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    format(path, sizeof(path), "Players/%s.ini", name);

    dini_Create(path);
    SetPlayerScore(playerid, dini_Int(path, "Score"));

    g_PlayerSec[playerid] = 0;
    return 1;
}

// 每分钟 +1 原生Score
public Timer_MinuteScore()
{
    for(new i; i<MAX_PLAYERS; i++)
    {
        if(IsPlayerConnected(i) && !IsPlayerNPC(i))
        {
            g_PlayerSec[i]++;
            
            if(g_PlayerSec[i] >= 60)
            {
                SetPlayerScore(i, GetPlayerScore(i) + 1);
                g_PlayerSec[i] = 0;
                
                // 加分提示
                SendClientMessage(i, -1, "【在线奖励】在线1分钟，时间积分 +1！");
            }
        }
    }
}

// 退出时保存原生Score
public OnPlayerDisconnect(playerid, reason)
{
    new path[128], name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    format(path, sizeof(path), "Players/%s.ini", name);

    dini_IntSet(path, "Score", GetPlayerScore(playerid));
    return 1;
}
