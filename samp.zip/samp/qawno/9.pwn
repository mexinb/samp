// ============================================================
// �ļ�: mysql_login.pwn
// ����: MySQL ��¼ϵͳ���� strcat���ȶ��棩
// ����: mexinb666
// ����: /start �鿴��Ϣ | /pd ǩ��
// ����: SA-MP 0.3.7+����Ҫ MySQL ���
// ============================================================

#include <a_samp>
#include <float>
#include <a_mysql>

#define MAX_PASSWORD_LEN 24
#define LEVEL_REWARD 100000
#define SCORE_PER_LEVEL 1000

#define COLOR_GREEN 0x33FF33AA
#define COLOR_RED   0xFF3333AA
#define COLOR_YELLOW 0xFFFF33AA

#define MYSQL_HOST "localhost"
#define MYSQL_USER "samp_user"
#define MYSQL_DB   "samp_db"
#define MYSQL_PASS "mexinb666"

enum PlayerData {
    pID,
    pPassword[129],
    pRegTime,
    pLastLogin,
    pLastExit,
    Float:pLastPosX,
    Float:pLastPosY,
    Float:pLastPosZ,
    pTimeScore,
    pLastSign[11],
    pMoney,
    pLoggedIn,
    pLoaded
}

new g_PlayerData[MAX_PLAYERS][PlayerData];
new MySQL:g_SQL;
new g_TimeScoreTimer[MAX_PLAYERS];

stock GetPlayerNameEx(playerid) {
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    return name;
}

stock GetCurrentDate(dest[], len = 11) {
    new year, month, day;
    getdate(year, month, day);
    format(dest, len, "%d-%02d-%02d", year, month, day);
}

stock InitDatabase() {
    g_SQL = mysql_connect(MYSQL_HOST, MYSQL_USER, MYSQL_DB, MYSQL_PASS);
    if (mysql_errno(g_SQL) != 0) {
        print("? MySQL ����ʧ�ܣ�");
        return 0;
    }
    print("? MySQL ���ӳɹ���");
    mysql_query(g_SQL, "CREATE TABLE IF NOT EXISTS players (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(24) UNIQUE NOT NULL, password VARCHAR(129) NOT NULL, regtime INT DEFAULT 0, lastlogin INT DEFAULT 0, lastexit INT DEFAULT 0, posx FLOAT DEFAULT 0.0, posy FLOAT DEFAULT 0.0, posz FLOAT DEFAULT 3.0, timescore INT DEFAULT 0, lastsign VARCHAR(11) DEFAULT '', money INT DEFAULT 0)");
    return 1;
}

stock LoadPlayerData(playerid) {
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    new query[256];
    format(query, sizeof(query), "SELECT * FROM players WHERE name = '%e'", name);
    new Cache:result = mysql_query(g_SQL, query);
    if (cache_num_rows() > 0) {
        g_PlayerData[playerid][pID] = cache_get_field_content_int(0, "id");
        g_PlayerData[playerid][pRegTime] = cache_get_field_content_int(0, "regtime");
        g_PlayerData[playerid][pLastLogin] = cache_get_field_content_int(0, "lastlogin");
        g_PlayerData[playerid][pLastExit] = cache_get_field_content_int(0, "lastexit");
        g_PlayerData[playerid][pLastPosX] = cache_get_field_content_float(0, "posx");
        g_PlayerData[playerid][pLastPosY] = cache_get_field_content_float(0, "posy");
        g_PlayerData[playerid][pLastPosZ] = cache_get_field_content_float(0, "posz");
        g_PlayerData[playerid][pTimeScore] = cache_get_field_content_int(0, "timescore");
        g_PlayerData[playerid][pMoney] = cache_get_field_content_int(0, "money");
        cache_get_field_content(0, "password", g_PlayerData[playerid][pPassword], 129);
        cache_get_field_content(0, "lastsign", g_PlayerData[playerid][pLastSign], 11);
        g_PlayerData[playerid][pLoaded] = 1;
        cache_delete(result);
        return 1;
    }
    cache_delete(result);
    return 0;
}

stock RegisterPlayer(playerid, const password[]) {
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    new regtime = gettime();
    new query[512];
    format(query, sizeof(query), "INSERT INTO players (name, password, regtime, lastlogin) VALUES ('%e', '%e', %d, %d)", name, password, regtime, regtime);
    mysql_query(g_SQL, query);
    return LoadPlayerData(playerid);
}

stock UpdatePlayerData(playerid) {
    if (!g_PlayerData[playerid][pLoaded]) return 0;
    new query[1024];
    format(query, sizeof(query), "UPDATE players SET lastlogin=%d, lastexit=%d, posx=%.2f, posy=%.2f, posz=%.2f, timescore=%d, lastsign='%e', money=%d WHERE id=%d",
        g_PlayerData[playerid][pLastLogin],
        g_PlayerData[playerid][pLastExit],
        g_PlayerData[playerid][pLastPosX],
        g_PlayerData[playerid][pLastPosY],
        g_PlayerData[playerid][pLastPosZ],
        g_PlayerData[playerid][pTimeScore],
        g_PlayerData[playerid][pLastSign],
        g_PlayerData[playerid][pMoney],
        g_PlayerData[playerid][pID]
    );
    mysql_query(g_SQL, query);
    return 1;
}

stock CheckPassword(playerid, const input[]) {
    return strcmp(g_PlayerData[playerid][pPassword], input) == 0;
}

forward ForcePlayerSave(playerid);
public ForcePlayerSave(playerid) {
    if (!IsPlayerConnected(playerid) || !g_PlayerData[playerid][pLoggedIn]) return 0;
    GetPlayerPos(playerid, g_PlayerData[playerid][pLastPosX], g_PlayerData[playerid][pLastPosY], g_PlayerData[playerid][pLastPosZ]);
    g_PlayerData[playerid][pMoney] = GetPlayerMoney(playerid);
    UpdatePlayerData(playerid);
    return 1;
}

forward AddTimeScore(playerid);
public AddTimeScore(playerid) {
    if (!g_PlayerData[playerid][pLoggedIn]) return 1;
    new oldLevel = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    g_PlayerData[playerid][pTimeScore] += 1;
    new newLevel = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    if (newLevel > oldLevel) {
        new reward = (newLevel - oldLevel) * LEVEL_REWARD;
        g_PlayerData[playerid][pMoney] += reward;
        GivePlayerMoney(playerid, reward);
        new msg[128];
        format(msg, sizeof(msg), "��ϲ���ȼ������� %d ������� $%d ������", newLevel, reward);
        SendClientMessage(playerid, COLOR_YELLOW, msg);
        SetPlayerScore(playerid, newLevel);
    }
    UpdatePlayerData(playerid);
    return 1;
}

stock SignPlayer(playerid) {
    new today[11];
    GetCurrentDate(today, sizeof(today));
    if (strcmp(g_PlayerData[playerid][pLastSign], today) == 0) {
        SendClientMessage(playerid, COLOR_RED, "������Ѿ�ǩ�����ˣ�");
        return 0;
    }
    new randTime = random(91) + 10;
    new randMoney = random(4001) + 1000;
    g_PlayerData[playerid][pTimeScore] += randTime;
    g_PlayerData[playerid][pMoney] += randMoney;
    GivePlayerMoney(playerid, randMoney);
    new level = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    SetPlayerScore(playerid, level);
    format(g_PlayerData[playerid][pLastSign], 11, today);
    UpdatePlayerData(playerid);
    new msg[128];
    format(msg, sizeof(msg), "ǩ���ɹ������ %d ʱ��ֺ� $%d��", randTime, randMoney);
    SendClientMessage(playerid, COLOR_GREEN, msg);
    return 1;
}

stock RestorePlayerState(playerid) {
    ResetPlayerMoney(playerid);
    GivePlayerMoney(playerid, g_PlayerData[playerid][pMoney]);
    new level = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    SetPlayerScore(playerid, level);
    SetPlayerPos(playerid, g_PlayerData[playerid][pLastPosX], g_PlayerData[playerid][pLastPosY], g_PlayerData[playerid][pLastPosZ]);
    TogglePlayerControllable(playerid, 1);
    if (g_TimeScoreTimer[playerid] != -1) KillTimer(g_TimeScoreTimer[playerid]);
    g_TimeScoreTimer[playerid] = SetTimerEx("AddTimeScore", 60000, true, "i", playerid);
    new msg[128];
    format(msg, sizeof(msg), "��ӭ�������ȼ�:%d ʱ���:%d ��Ǯ:$%d", level, g_PlayerData[playerid][pTimeScore], g_PlayerData[playerid][pMoney]);
    SendClientMessage(playerid, COLOR_GREEN, msg);
}

public OnPlayerCommandText(playerid, cmdtext[]) {
    if (!g_PlayerData[playerid][pLoggedIn]) {
        SendClientMessage(playerid, COLOR_RED, "���ȵ�¼��");
        return 1;
    }
    if (strcmp(cmdtext, "/start", true) == 0) {
        new level = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
        new msg[256];
        format(msg, sizeof(msg), "=== �����Ϣ ===\n����: %s\n�ȼ�: %d\nʱ���: %d\n��Ǯ: $%d\nע��ʱ��: %d\n�ϴ��˳�λ��: %.2f, %.2f, %.2f",
            GetPlayerNameEx(playerid), level,
            g_PlayerData[playerid][pTimeScore],
            g_PlayerData[playerid][pMoney],
            g_PlayerData[playerid][pRegTime],
            g_PlayerData[playerid][pLastPosX],
            g_PlayerData[playerid][pLastPosY],
            g_PlayerData[playerid][pLastPosZ]
        );
        ShowPlayerDialog(playerid, 0, DIALOG_STYLE_MSGBOX, "������Ϣ", msg, "�ر�", "");
        return 1;
    }
    if (strcmp(cmdtext, "/pd", true) == 0) {
        SignPlayer(playerid);
        return 1;
    }
    if (strcmp(cmdtext, "/help", true) == 0) {
        SendClientMessage(playerid, COLOR_YELLOW, "��������: /start - �鿴������Ϣ, /pd - ÿ��ǩ��");
        return 1;
    }
    return 0;
}

public OnPlayerConnect(playerid) {
    g_PlayerData[playerid][pLoaded] = 0;
    g_PlayerData[playerid][pLoggedIn] = 0;
    g_TimeScoreTimer[playerid] = -1;
    TogglePlayerControllable(playerid, 0);
    if (LoadPlayerData(playerid)) {
        ShowPlayerDialog(playerid, 1000, DIALOG_STYLE_INPUT, "��¼ϵͳ", "���������룺", "��¼", "�˳�");
    } else {
        ShowPlayerDialog(playerid, 1001, DIALOG_STYLE_INPUT, "ע��ϵͳ", "���������루1-24λ����", "ע��", "�˳�");
    }
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]) {
    if (dialogid == 1000) {
        if (!response) return Kick(playerid);
        if (strlen(inputtext) < 1 || strlen(inputtext) > MAX_PASSWORD_LEN) {
            SendClientMessage(playerid, COLOR_RED, "���볤�ȱ����� 1-24 ֮�䣡");
            ShowPlayerDialog(playerid, 1000, DIALOG_STYLE_INPUT, "��¼ϵͳ", "���������룺", "��¼", "�˳�");
            return 1;
        }
        if (!CheckPassword(playerid, inputtext)) {
            SendClientMessage(playerid, COLOR_RED, "�������");
            ShowPlayerDialog(playerid, 1000, DIALOG_STYLE_INPUT, "��¼ϵͳ", "���������룺", "��¼", "�˳�");
            return 1;
        }
        g_PlayerData[playerid][pLoggedIn] = 1;
        g_PlayerData[playerid][pLastLogin] = gettime();
        UpdatePlayerData(playerid);
        SendClientMessage(playerid, COLOR_GREEN, "��¼�ɹ���");
        RestorePlayerState(playerid);
        return 1;
    }
    if (dialogid == 1001) {
        if (!response) return Kick(playerid);
        if (strlen(inputtext) < 1 || strlen(inputtext) > MAX_PASSWORD_LEN) {
            SendClientMessage(playerid, COLOR_RED, "���볤�ȱ����� 1-24 ֮�䣡");
            ShowPlayerDialog(playerid, 1001, DIALOG_STYLE_INPUT, "ע��ϵͳ", "���������루1-24λ����", "ע��", "�˳�");
            return 1;
        }
        if (RegisterPlayer(playerid, inputtext)) {
            g_PlayerData[playerid][pLoggedIn] = 1;
            g_PlayerData[playerid][pLastLogin] = gettime();
            g_PlayerData[playerid][pMoney] = 0;
            SendClientMessage(playerid, COLOR_GREEN, "ע��ɹ�����ӭ���룡");
            RestorePlayerState(playerid);
        } else {
            SendClientMessage(playerid, COLOR_RED, "ע��ʧ�ܣ����������ӣ�");
            Kick(playerid);
        }
        return 1;
    }
    return 0;
}

public OnPlayerDisconnect(playerid, reason) {
    if (g_PlayerData[playerid][pLoggedIn]) {
        GetPlayerPos(playerid, g_PlayerData[playerid][pLastPosX], g_PlayerData[playerid][pLastPosY], g_PlayerData[playerid][pLastPosZ]);
        g_PlayerData[playerid][pLastExit] = gettime();
        g_PlayerData[playerid][pMoney] = GetPlayerMoney(playerid);
        UpdatePlayerData(playerid);
    }
    if (g_TimeScoreTimer[playerid] != -1) KillTimer(g_TimeScoreTimer[playerid]);
    return 1;
}

public OnFilterScriptInit() {
    InitDatabase();
    print("\n======================================");
    print("   MySQL ��¼ϵͳ�Ѽ���");
    print("   ����: mexinb666");
    print("   ����: /start �鿴��Ϣ | /pd ǩ��");
    print("======================================\n");
    return 1;
}

public OnFilterScriptExit() {
    mysql_close(g_SQL);
    print("��¼ϵͳ��ж��");
    return 1;
}