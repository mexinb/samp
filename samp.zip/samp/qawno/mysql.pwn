// ============================================================
// 文件: login.pwn
// 描述: 完善的登录系统 - SQLite版，支持时间分、金钱、坐标实时保存
// 功能: /start 查看信息 | /pd 签到 | /help 帮助
// 特色: 自动小时奖励（每60时间分额外+10分+$1000），定时保存，数据防丢
// 环境: SA-MP 0.3.7+
// ============================================================

#include <a_samp>
#include <float>
#include <a_sampdb>

// ---------- 配置常量 ----------
#define MAX_PASSWORD_LEN        24          // 密码最大长度
#define LEVEL_REWARD            100000      // 升级奖励金额
#define SCORE_PER_LEVEL         1000        // 每级所需时间分
#define AUTO_SAVE_INTERVAL      30000       // 自动保存间隔(毫秒) 30秒
#define HOURLY_BONUS_SCORE      10          // 每小时额外奖励时间分
#define HOURLY_BONUS_MONEY      1000        // 每小时额外奖励金钱

#define COLOR_GREEN             0x33FF33AA
#define COLOR_RED               0xFF3333AA
#define COLOR_YELLOW            0xFFFF33AA

// ---------- 玩家数据结构 ----------
enum PlayerData {
    pID,                                // 数据库ID
    pPassword[129],                     // 密码(明文存储，生产环境建议哈希)
    pRegTime,                           // 注册时间戳
    pLastLogin,                         // 最后登录时间戳
    pLastExit,                          // 最后退出时间戳
    Float:pLastPosX,                    // 最后位置X
    Float:pLastPosY,                    // 最后位置Y
    Float:pLastPosZ,                    // 最后位置Z
    pTimeScore,                         // 总时间分
    pLastSign[11],                      // 上次签到日期(YYYY-MM-DD)
    pMoney,                             // 金钱(与服务器金钱同步)
    pLoggedIn,                          // 是否已登录
    pLoaded,                            // 数据是否已加载
    pLastHourReward                     // 上次已结算的小时数(pTimeScore / 60)
}

// ---------- 全局变量 ----------
new g_PlayerData[MAX_PLAYERS][PlayerData];
new DB:g_Database;
new g_TimeScoreTimer[MAX_PLAYERS];
new g_AutoSaveTimer;                    // 全局自动保存计时器

// ---------- 辅助函数 ----------
stock GetPlayerNameEx(playerid) {
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    return name;
}

// 获取当前日期字符串(格式: YYYY-MM-DD)
stock GetCurrentDate(dest[], len = 11) {
    new year, month, day;
    getdate(year, month, day);
    format(dest, len, "%d-%02d-%02d", year, month, day);
}

// SQL字符串转义(防止注入)
stock EscapeString(const source[], dest[], maxlen) {
    new idx = 0;
    for (new i = 0; source[i] != EOS && idx < maxlen - 2; i++) {
        if (source[i] == '\'') {
            dest[idx++] = '\'';
            dest[idx++] = '\'';
        } else {
            dest[idx++] = source[i];
        }
    }
    dest[idx] = EOS;
}

// ---------- 数据库操作(安全版本) ----------
stock InitDatabase() {
    g_Database = db_open("samp.db");
    if (g_Database == DB:0) {
        print("[错误] 数据库打开失败！");
        return 0;
    }
    // 创建表，增加 last_hour_reward 字段用于记录小时奖励进度
    db_query(g_Database, "CREATE TABLE IF NOT EXISTS players (id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR(24) UNIQUE NOT NULL, password VARCHAR(129) NOT NULL, regtime INTEGER DEFAULT 0, lastlogin INTEGER DEFAULT 0, lastexit INTEGER DEFAULT 0, posx REAL DEFAULT 0.0, posy REAL DEFAULT 0.0, posz REAL DEFAULT 3.0, timescore INTEGER DEFAULT 0, lastsign VARCHAR(11) DEFAULT '', money INTEGER DEFAULT 0, last_hour_reward INTEGER DEFAULT 0)");
    print("[数据库] 初始化成功");
    return 1;
}

// 加载玩家数据
stock LoadPlayerData(playerid) {
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    new escapedName[48];
    EscapeString(name, escapedName, sizeof(escapedName));
    
    new query[256];
    format(query, sizeof(query), "SELECT * FROM players WHERE name = '%s'", escapedName);
    new DBResult:result = db_query(g_Database, query);
    
    if (db_num_rows(result) > 0) {
        g_PlayerData[playerid][pID] = db_get_field_assoc_int(result, "id");
        g_PlayerData[playerid][pRegTime] = db_get_field_assoc_int(result, "regtime");
        g_PlayerData[playerid][pLastLogin] = db_get_field_assoc_int(result, "lastlogin");
        g_PlayerData[playerid][pLastExit] = db_get_field_assoc_int(result, "lastexit");
        g_PlayerData[playerid][pLastPosX] = db_get_field_assoc_float(result, "posx");
        g_PlayerData[playerid][pLastPosY] = db_get_field_assoc_float(result, "posy");
        g_PlayerData[playerid][pLastPosZ] = db_get_field_assoc_float(result, "posz");
        g_PlayerData[playerid][pTimeScore] = db_get_field_assoc_int(result, "timescore");
        g_PlayerData[playerid][pMoney] = db_get_field_assoc_int(result, "money");
        g_PlayerData[playerid][pLastHourReward] = db_get_field_assoc_int(result, "last_hour_reward");
        db_get_field_assoc(result, "password", g_PlayerData[playerid][pPassword], 129);
        db_get_field_assoc(result, "lastsign", g_PlayerData[playerid][pLastSign], 11);
        g_PlayerData[playerid][pLoaded] = 1;
        db_free_result(result);
        return 1;
    }
    db_free_result(result);
    return 0;
}

// 注册新玩家
stock RegisterPlayer(playerid, const password[]) {
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    new escapedName[48], escapedPass[130];
    EscapeString(name, escapedName, sizeof(escapedName));
    EscapeString(password, escapedPass, sizeof(escapedPass));
    
    new regtime = gettime();
    new query[512];
    format(query, sizeof(query), "INSERT INTO players (name, password, regtime, lastlogin, last_hour_reward) VALUES ('%s', '%s', %d, %d, 0)", 
        escapedName, escapedPass, regtime, regtime);
    db_query(g_Database, query);
    return LoadPlayerData(playerid);
}

// 保存玩家所有数据到数据库(核心保存函数)
stock UpdatePlayerData(playerid) {
    if (!g_PlayerData[playerid][pLoaded]) return 0;
    
    // 同步服务器实际金钱到变量(防止外部插件修改)
    g_PlayerData[playerid][pMoney] = GetPlayerMoney(playerid);
    
    new escapedSign[20];
    EscapeString(g_PlayerData[playerid][pLastSign], escapedSign, sizeof(escapedSign));
    
    new query[1024];
    format(query, sizeof(query), 
        "UPDATE players SET lastlogin=%d, lastexit=%d, posx=%.2f, posy=%.2f, posz=%.2f, timescore=%d, lastsign='%s', money=%d, last_hour_reward=%d WHERE id=%d",
        g_PlayerData[playerid][pLastLogin],
        g_PlayerData[playerid][pLastExit],
        g_PlayerData[playerid][pLastPosX],
        g_PlayerData[playerid][pLastPosY],
        g_PlayerData[playerid][pLastPosZ],
        g_PlayerData[playerid][pTimeScore],
        escapedSign,
        g_PlayerData[playerid][pMoney],
        g_PlayerData[playerid][pLastHourReward],
        g_PlayerData[playerid][pID]
    );
    db_query(g_Database, query);
    return 1;
}

// 密码验证
stock CheckPassword(playerid, const input[]) {
    return strcmp(g_PlayerData[playerid][pPassword], input) == 0;
}

// ---------- 小时奖励处理(核心逻辑) ----------
// 根据当前时间分，补发所有未结算的小时奖励
stock ProcessHourlyRewards(playerid) {
    if (!g_PlayerData[playerid][pLoggedIn]) return 0;
    
    new currentHours = g_PlayerData[playerid][pTimeScore] / 60;
    new rewardedHours = g_PlayerData[playerid][pLastHourReward];
    
    if (currentHours > rewardedHours) {
        new hoursEarned = currentHours - rewardedHours;
        new totalBonusScore = hoursEarned * HOURLY_BONUS_SCORE;
        new totalBonusMoney = hoursEarned * HOURLY_BONUS_MONEY;
        
        // 发放奖励
        g_PlayerData[playerid][pTimeScore] += totalBonusScore;
        g_PlayerData[playerid][pMoney] += totalBonusMoney;
        GivePlayerMoney(playerid, totalBonusMoney);
        
        // 更新已奖励小时数
        g_PlayerData[playerid][pLastHourReward] = currentHours;
        
        // 提示玩家
        new msg[128];
        format(msg, sizeof(msg), "🏆 在线奖励：累计在线 %d 小时，获得 %d 时间分 + $%d！", 
            currentHours, totalBonusScore, totalBonusMoney);
        SendClientMessage(playerid, COLOR_YELLOW, msg);
        
        // 重新计算等级并同步
        new newLevel = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
        SetPlayerScore(playerid, newLevel);
        
        // 保存数据
        UpdatePlayerData(playerid);
        return 1;
    }
    return 0;
}

// 增加时间分(通用函数，会自动触发小时奖励和升级)
stock AddTimeScorePoints(playerid, points) {
    if (!g_PlayerData[playerid][pLoggedIn]) return 0;
    if (points <= 0) return 0;
    
    new oldLevel = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    g_PlayerData[playerid][pTimeScore] += points;
    new newLevel = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    
    // 等级提升奖励
    if (newLevel > oldLevel) {
        new reward = (newLevel - oldLevel) * LEVEL_REWARD;
        g_PlayerData[playerid][pMoney] += reward;
        GivePlayerMoney(playerid, reward);
        new msg[128];
        format(msg, sizeof(msg), "🎉 恭喜！等级提升到 %d 级，获得 $%d 奖励！", newLevel, reward);
        SendClientMessage(playerid, COLOR_YELLOW, msg);
        SetPlayerScore(playerid, newLevel);
    }
    
    // 处理小时奖励(可能会再次增加时间分和金钱)
    ProcessHourlyRewards(playerid);
    
    // 保存数据
    UpdatePlayerData(playerid);
    return 1;
}

// ---------- 游戏逻辑 ----------
// 每分钟增加1时间分(定时器回调)
forward AddTimeScore(playerid);
public AddTimeScore(playerid) {
    if (!IsPlayerConnected(playerid)) return 1;
    if (!g_PlayerData[playerid][pLoggedIn]) return 1;
    
    AddTimeScorePoints(playerid, 1);
    return 1;
}

// 签到功能
stock SignPlayer(playerid) {
    new today[11];
    GetCurrentDate(today, sizeof(today));
    if (strcmp(g_PlayerData[playerid][pLastSign], today) == 0) {
        SendClientMessage(playerid, COLOR_RED, "❌ 你今天已经签到过了！");
        return 0;
    }
    
    new randTime = random(491) + 10;        // 10~500 时间分
    new randMoney = random(4001) + 1000;    // 1000~5000 金钱
    
    // 增加时间分(自动触发小时奖励和等级)
    AddTimeScorePoints(playerid, randTime);
    
    // 金钱已经在 AddTimeScorePoints 中同步，但签到额外金钱需要单独加
    // 注意: AddTimeScorePoints 不会加签到金钱，这里需要额外处理
    g_PlayerData[playerid][pMoney] += randMoney;
    GivePlayerMoney(playerid, randMoney);
    
    // 更新签到日期
    format(g_PlayerData[playerid][pLastSign], 11, today);
    
    // 再次保存(确保签到日期写入)
    UpdatePlayerData(playerid);
    
    new msg[128];
    format(msg, sizeof(msg), "✅ 签到成功！获得 %d 时间分和 $%d！", randTime, randMoney);
    SendClientMessage(playerid, COLOR_GREEN, msg);
    return 1;
}

// 恢复玩家状态(登录时调用)
stock RestorePlayerState(playerid) {
    // 同步金钱
    ResetPlayerMoney(playerid);
    GivePlayerMoney(playerid, g_PlayerData[playerid][pMoney]);
    
    // 同步等级
    new level = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
    SetPlayerScore(playerid, level);
    
    // 恢复坐标(增加边界检查)
    new Float:x = g_PlayerData[playerid][pLastPosX];
    new Float:y = g_PlayerData[playerid][pLastPosY];
    new Float:z = g_PlayerData[playerid][pLastPosZ];
    if (x == 0.0 && y == 0.0 && z == 0.0) {
        x = 0.0; y = 0.0; z = 3.0; // 默认出生点
    }
    SetPlayerPos(playerid, x, y, z);
    TogglePlayerControllable(playerid, 1);
    
    // 启动时间分计时器
    if (g_TimeScoreTimer[playerid] != -1) KillTimer(g_TimeScoreTimer[playerid]);
    g_TimeScoreTimer[playerid] = SetTimerEx("AddTimeScore", 60000, true, "i", playerid);
    
    // 处理登录时可能遗漏的小时奖励
    ProcessHourlyRewards(playerid);
    
    new msg[128];
    format(msg, sizeof(msg), "🎮 欢迎回来！等级:%d 时间分:%d 金钱:$%d", level, g_PlayerData[playerid][pTimeScore], g_PlayerData[playerid][pMoney]);
    SendClientMessage(playerid, COLOR_GREEN, msg);
}

// ---------- 外部调用接口(强制保存) ----------
forward ForcePlayerSave(playerid);
public ForcePlayerSave(playerid) {
    if (!IsPlayerConnected(playerid)) return 0;
    if (!g_PlayerData[playerid][pLoggedIn]) return 0;
    GetPlayerPos(playerid, g_PlayerData[playerid][pLastPosX], g_PlayerData[playerid][pLastPosY], g_PlayerData[playerid][pLastPosZ]);
    g_PlayerData[playerid][pMoney] = GetPlayerMoney(playerid);
    UpdatePlayerData(playerid);
    return 1;
}

// 自动保存所有在线玩家
forward AutoSaveAllPlayers();
public AutoSaveAllPlayers() {
    for (new i = 0; i < MAX_PLAYERS; i++) {
        if (IsPlayerConnected(i) && g_PlayerData[i][pLoggedIn]) {
            ForcePlayerSave(i);
        }
    }
    return 1;
}

// ---------- 命令处理 ----------
public OnPlayerCommandText(playerid, cmdtext[]) {
    if (!g_PlayerData[playerid][pLoggedIn]) {
        SendClientMessage(playerid, COLOR_RED, "请先登录！");
        return 1;
    }
    
    if (strcmp(cmdtext, "/start", true) == 0) {
        new level = g_PlayerData[playerid][pTimeScore] / SCORE_PER_LEVEL;
        new msg[512];
        format(msg, sizeof(msg), 
            "=== 📊 玩家信息 ===\n\
            名称: %s\n\
            等级: %d\n\
            时间分: %d\n\
            金钱: $%d\n\
            注册时间: %s\n\
            上次位置: %.2f, %.2f, %.2f\n\
            =================",
            GetPlayerNameEx(playerid), level,
            g_PlayerData[playerid][pTimeScore],
            g_PlayerData[playerid][pMoney],
            g_PlayerData[playerid][pRegTime] ? "已注册" : "未知",  // 简化显示
            g_PlayerData[playerid][pLastPosX],
            g_PlayerData[playerid][pLastPosY],
            g_PlayerData[playerid][pLastPosZ]
        );
        ShowPlayerDialog(playerid, 0, DIALOG_STYLE_MSGBOX, "个人信息", msg, "关闭", "");
        return 1;
    }
    
    if (strcmp(cmdtext, "/pd", true) == 0) {
        SignPlayer(playerid);
        return 1;
    }
    
    if (strcmp(cmdtext, "/help", true) == 0) {
        SendClientMessage(playerid, COLOR_YELLOW, "📢 可用命令: /start - 查看信息, /pd - 每日签到");
        return 1;
    }
    
    return 0;
}

// ---------- 连接/登录流程 ----------
public OnPlayerConnect(playerid) {
    // 重置所有数据
    g_PlayerData[playerid][pLoaded] = 0;
    g_PlayerData[playerid][pLoggedIn] = 0;
    g_PlayerData[playerid][pLastHourReward] = 0;
    g_TimeScoreTimer[playerid] = -1;
    
    TogglePlayerControllable(playerid, 0);
    
    if (LoadPlayerData(playerid)) {
        ShowPlayerDialog(playerid, 1000, DIALOG_STYLE_INPUT, "🔐 登录系统", "请输入密码：", "登录", "退出");
    } else {
        ShowPlayerDialog(playerid, 1001, DIALOG_STYLE_INPUT, "📝 注册系统", "请设置密码（1-24位）：", "注册", "退出");
    }
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]) {
    if (dialogid == 1000) {  // 登录对话框
        if (!response) return Kick(playerid);
        if (strlen(inputtext) < 1 || strlen(inputtext) > MAX_PASSWORD_LEN) {
            SendClientMessage(playerid, COLOR_RED, "密码长度必须在 1-24 之间！");
            ShowPlayerDialog(playerid, 1000, DIALOG_STYLE_INPUT, "登录系统", "请输入密码：", "登录", "退出");
            return 1;
        }
        if (!CheckPassword(playerid, inputtext)) {
            SendClientMessage(playerid, COLOR_RED, "密码错误！");
            ShowPlayerDialog(playerid, 1000, DIALOG_STYLE_INPUT, "登录系统", "请输入密码：", "登录", "退出");
            return 1;
        }
        g_PlayerData[playerid][pLoggedIn] = 1;
        g_PlayerData[playerid][pLastLogin] = gettime();
        UpdatePlayerData(playerid);
        SendClientMessage(playerid, COLOR_GREEN, "✅ 登录成功！");
        RestorePlayerState(playerid);
        return 1;
    }
    
    if (dialogid == 1001) {  // 注册对话框
        if (!response) return Kick(playerid);
        if (strlen(inputtext) < 1 || strlen(inputtext) > MAX_PASSWORD_LEN) {
            SendClientMessage(playerid, COLOR_RED, "密码长度必须在 1-24 之间！");
            ShowPlayerDialog(playerid, 1001, DIALOG_STYLE_INPUT, "注册系统", "请设置密码（1-24位）：", "注册", "退出");
            return 1;
        }
        if (RegisterPlayer(playerid, inputtext)) {
            g_PlayerData[playerid][pLoggedIn] = 1;
            g_PlayerData[playerid][pLastLogin] = gettime();
            g_PlayerData[playerid][pMoney] = 0;
            g_PlayerData[playerid][pTimeScore] = 0;
            g_PlayerData[playerid][pLastHourReward] = 0;
            UpdatePlayerData(playerid);
            SendClientMessage(playerid, COLOR_GREEN, "🎉 注册成功！欢迎加入！");
            RestorePlayerState(playerid);
        } else {
            SendClientMessage(playerid, COLOR_RED, "注册失败，请重新连接！");
            Kick(playerid);
        }
        return 1;
    }
    return 0;
}

// ---------- 玩家退出时保存 ----------
public OnPlayerDisconnect(playerid, reason) {
    if (g_PlayerData[playerid][pLoggedIn]) {
        GetPlayerPos(playerid, g_PlayerData[playerid][pLastPosX], g_PlayerData[playerid][pLastPosY], g_PlayerData[playerid][pLastPosZ]);
        g_PlayerData[playerid][pLastExit] = gettime();
        g_PlayerData[playerid][pMoney] = GetPlayerMoney(playerid);
        UpdatePlayerData(playerid);
    }
    if (g_TimeScoreTimer[playerid] != -1) {
        KillTimer(g_TimeScoreTimer[playerid]);
        g_TimeScoreTimer[playerid] = -1;
    }
    return 1;
}

// ---------- 初始化/卸载 ----------
public OnFilterScriptInit() {
    InitDatabase();
    // 启动自动保存定时器(每30秒)
    g_AutoSaveTimer = SetTimer("AutoSaveAllPlayers", AUTO_SAVE_INTERVAL, true);
    
    print("\n======================================");
    print("   ✨ 完美登录系统已加载 ✨");
    print("   功能: 自动保存 | 小时奖励 | 签到系统");
    print("   命令: /start 查看信息 | /pd 签到");
    print("======================================\n");
    return 1;
}

public OnFilterScriptExit() {
    // 停止所有定时器
    KillTimer(g_AutoSaveTimer);
    for (new i = 0; i < MAX_PLAYERS; i++) {
        if (g_TimeScoreTimer[i] != -1) {
            KillTimer(g_TimeScoreTimer[i]);
        }
    }
    // 保存所有在线玩家
    AutoSaveAllPlayers();
    if (g_Database != DB:0) db_close(g_Database);
    print("登录系统已卸载，数据已保存");
    return 1;
}