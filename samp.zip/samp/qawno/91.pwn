#include <a_samp>

forward CMD_91(playerid);
public CMD_91(playerid)
{
    SetPlayerScore(playerid, GetPlayerScore(playerid) + 10000);
    GivePlayerMoney(playerid, 10000);

    SendClientMessage(playerid, 0x00FF00FF, "[ϵͳ] ���ѻ�� 10000 ʱ��� + 10000 ��Ϸ�ң�");
    return 1;
}

public OnPlayerCommandText(playerid, cmdtext[])
{
    if (strcmp(cmdtext, "/91", true) == 0)
    {
        CMD_91(playerid);
        return 1;
    }
    return 0;
}
