// ============================================================
// �ļ�: skin.pwn
// ����: ͼ�λ�Ƥ���˵�����ԭ��PlayerTextDraw��3Dģ��Ԥ����
// ����: /skin [ID] �� /skin list
// ����: SA-MP 0.3.7+
// ============================================================

#include <a_samp>

#define SKINS_PER_PAGE    21
#define MAX_SKINS         312

// Ƥ������
new g_SkinModels[MAX_SKINS];
new g_SkinNames[MAX_SKINS][32];
new g_TotalSkins = 0;

// �������
new g_CurrentPage[MAX_PLAYERS];
new g_MenuOpen[MAX_PLAYERS];
new PlayerText:g_SkinTD[MAX_PLAYERS][SKINS_PER_PAGE];
new PlayerText:g_PrevTD[MAX_PLAYERS];
new PlayerText:g_NextTD[MAX_PLAYERS];
new PlayerText:g_PageInfoTD[MAX_PLAYERS];
new PlayerText:g_MenuBackground[MAX_PLAYERS];

forward OnPlayerCancelSelectTextDraw(playerid);

// ---------- strtok ���� ----------
new g_strtok_idx;
stock strtok(const string[], &index, dest[], max_len) {
    new len = strlen(string);
    new pos = index;
    while(pos < len && string[pos] == ' ') pos++;
    if(pos >= len) {
        dest[0] = 0;
        index = len;
        return 0;
    }
    new start = pos;
    while(pos < len && string[pos] != ' ') pos++;
    new end = pos;
    new copy_len = (end - start) > (max_len-1) ? (max_len-1) : (end - start);
    strmid(dest, string, start, start + copy_len);
    dest[copy_len] = 0;
    index = pos;
    return 1;
}

// ---------- ����Ƥ������ ----------
stock LoadSkinData() {
    g_TotalSkins = 0;
    for(new skinid = 0; skinid < MAX_SKINS; skinid++) {
        g_SkinModels[g_TotalSkins] = skinid;
        
        // ����Ƥ�����ƣ�0-299�йٷ����ƣ�300-311��Ĭ�ϣ�
        switch(skinid) {
            case 0: g_SkinNames[g_TotalSkins] = "CJ";
            case 1: g_SkinNames[g_TotalSkins] = "The Truth";
            case 2: g_SkinNames[g_TotalSkins] = "Maccer";
            case 3: g_SkinNames[g_TotalSkins] = "Andre";
            case 4: g_SkinNames[g_TotalSkins] = "Barry";
            case 5: g_SkinNames[g_TotalSkins] = "Jethro";
            case 6: g_SkinNames[g_TotalSkins] = "Kendl";
            case 7: g_SkinNames[g_TotalSkins] = "Helena";
            case 8: g_SkinNames[g_TotalSkins] = "Michelle";
            case 9: g_SkinNames[g_TotalSkins] = "Barbara";
            case 10: g_SkinNames[g_TotalSkins] = "Katie";
            case 11: g_SkinNames[g_TotalSkins] = "Millie";
            case 12: g_SkinNames[g_TotalSkins] = "Denise";
            case 13: g_SkinNames[g_TotalSkins] = "OG Loc";
            case 14: g_SkinNames[g_TotalSkins] = "Sweet";
            case 15: g_SkinNames[g_TotalSkins] = "Ryder";
            case 16: g_SkinNames[g_TotalSkins] = "Big Smoke";
            case 17: g_SkinNames[g_TotalSkins] = "Cesar Vialpando";
            case 18: g_SkinNames[g_TotalSkins] = "Toreno";
            case 19: g_SkinNames[g_TotalSkins] = "Mike Toreno";
            case 20: g_SkinNames[g_TotalSkins] = "Jizzy B.";
            case 21: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 22: g_SkinNames[g_TotalSkins] = "Catalina";
            case 23: g_SkinNames[g_TotalSkins] = "Wu Zi Mu";
            case 24: g_SkinNames[g_TotalSkins] = "Zero";
            case 25: g_SkinNames[g_TotalSkins] = "Ken Rosenberg";
            case 26: g_SkinNames[g_TotalSkins] = "Kent Paul";
            case 27: g_SkinNames[g_TotalSkins] = "Eddie Pulaski";
            case 28: g_SkinNames[g_TotalSkins] = "Frank Tenpenny";
            case 29: g_SkinNames[g_TotalSkins] = "Salvatore Leone";
            case 30: g_SkinNames[g_TotalSkins] = "Joey Leone";
            case 31: g_SkinNames[g_TotalSkins] = "Toni Cipriani";
            case 32: g_SkinNames[g_TotalSkins] = "Mafia Boss";
            case 33: g_SkinNames[g_TotalSkins] = "Triad Boss";
            case 34: g_SkinNames[g_TotalSkins] = "Triad";
            case 35: g_SkinNames[g_TotalSkins] = "Triad";
            case 36: g_SkinNames[g_TotalSkins] = "Triad";
            case 37: g_SkinNames[g_TotalSkins] = "Triad";
            case 38: g_SkinNames[g_TotalSkins] = "Triad";
            case 39: g_SkinNames[g_TotalSkins] = "Triad";
            case 40: g_SkinNames[g_TotalSkins] = "Ballaz";
            case 41: g_SkinNames[g_TotalSkins] = "Ballaz";
            case 42: g_SkinNames[g_TotalSkins] = "Ballaz";
            case 43: g_SkinNames[g_TotalSkins] = "Ballaz";
            case 44: g_SkinNames[g_TotalSkins] = "Ballaz";
            case 45: g_SkinNames[g_TotalSkins] = "Grove Street";
            case 46: g_SkinNames[g_TotalSkins] = "Grove Street";
            case 47: g_SkinNames[g_TotalSkins] = "Grove Street";
            case 48: g_SkinNames[g_TotalSkins] = "Grove Street";
            case 49: g_SkinNames[g_TotalSkins] = "Grove Street";
            case 50: g_SkinNames[g_TotalSkins] = "Vagos";
            case 51: g_SkinNames[g_TotalSkins] = "Vagos";
            case 52: g_SkinNames[g_TotalSkins] = "Vagos";
            case 53: g_SkinNames[g_TotalSkins] = "Vagos";
            case 54: g_SkinNames[g_TotalSkins] = "Vagos";
            case 55: g_SkinNames[g_TotalSkins] = "LSPD";
            case 56: g_SkinNames[g_TotalSkins] = "SFPD";
            case 57: g_SkinNames[g_TotalSkins] = "LVPD";
            case 58: g_SkinNames[g_TotalSkins] = "LSPD";
            case 59: g_SkinNames[g_TotalSkins] = "SFPD";
            case 60: g_SkinNames[g_TotalSkins] = "LVPD";
            case 61: g_SkinNames[g_TotalSkins] = "LSPD";
            case 62: g_SkinNames[g_TotalSkins] = "SFPD";
            case 63: g_SkinNames[g_TotalSkins] = "LVPD";
            case 64: g_SkinNames[g_TotalSkins] = "FBI Agent";
            case 65: g_SkinNames[g_TotalSkins] = "FBI Agent";
            case 66: g_SkinNames[g_TotalSkins] = "FBI Agent";
            case 67: g_SkinNames[g_TotalSkins] = "Army";
            case 68: g_SkinNames[g_TotalSkins] = "Desert";
            case 69: g_SkinNames[g_TotalSkins] = "Desert";
            case 70: g_SkinNames[g_TotalSkins] = "Pilot";
            case 71: g_SkinNames[g_TotalSkins] = "Pilot";
            case 72: g_SkinNames[g_TotalSkins] = "Pilot";
            case 73: g_SkinNames[g_TotalSkins] = "Pilot";
            case 74: g_SkinNames[g_TotalSkins] = "Paramedic";
            case 75: g_SkinNames[g_TotalSkins] = "Medic";
            case 76: g_SkinNames[g_TotalSkins] = "Firefighter";
            case 77: g_SkinNames[g_TotalSkins] = "Firefighter";
            case 78: g_SkinNames[g_TotalSkins] = "Firefighter";
            case 79: g_SkinNames[g_TotalSkins] = "Firefighter";
            case 80: g_SkinNames[g_TotalSkins] = "Biker";
            case 81: g_SkinNames[g_TotalSkins] = "Biker";
            case 82: g_SkinNames[g_TotalSkins] = "Biker";
            case 83: g_SkinNames[g_TotalSkins] = "Biker";
            case 84: g_SkinNames[g_TotalSkins] = "Biker";
            case 85: g_SkinNames[g_TotalSkins] = "Country";
            case 86: g_SkinNames[g_TotalSkins] = "Country";
            case 87: g_SkinNames[g_TotalSkins] = "Country";
            case 88: g_SkinNames[g_TotalSkins] = "Country";
            case 89: g_SkinNames[g_TotalSkins] = "Country";
            case 90: g_SkinNames[g_TotalSkins] = "Gangster";
            case 91: g_SkinNames[g_TotalSkins] = "Gangster";
            case 92: g_SkinNames[g_TotalSkins] = "Gangster";
            case 93: g_SkinNames[g_TotalSkins] = "Gangster";
            case 94: g_SkinNames[g_TotalSkins] = "Gangster";
            case 95: g_SkinNames[g_TotalSkins] = "Business";
            case 96: g_SkinNames[g_TotalSkins] = "Business";
            case 97: g_SkinNames[g_TotalSkins] = "Business";
            case 98: g_SkinNames[g_TotalSkins] = "Business";
            case 99: g_SkinNames[g_TotalSkins] = "Business";
            case 100: g_SkinNames[g_TotalSkins] = "Beach";
            case 101: g_SkinNames[g_TotalSkins] = "Beach";
            case 102: g_SkinNames[g_TotalSkins] = "Beach";
            case 103: g_SkinNames[g_TotalSkins] = "Beach";
            case 104: g_SkinNames[g_TotalSkins] = "Beach";
            case 105: g_SkinNames[g_TotalSkins] = "Tourist";
            case 106: g_SkinNames[g_TotalSkins] = "Tourist";
            case 107: g_SkinNames[g_TotalSkins] = "Tourist";
            case 108: g_SkinNames[g_TotalSkins] = "Tourist";
            case 109: g_SkinNames[g_TotalSkins] = "Tourist";
            case 110: g_SkinNames[g_TotalSkins] = "Worker";
            case 111: g_SkinNames[g_TotalSkins] = "Worker";
            case 112: g_SkinNames[g_TotalSkins] = "Worker";
            case 113: g_SkinNames[g_TotalSkins] = "Worker";
            case 114: g_SkinNames[g_TotalSkins] = "Worker";
            case 115: g_SkinNames[g_TotalSkins] = "Car Mechanic";
            case 116: g_SkinNames[g_TotalSkins] = "Car Mechanic";
            case 117: g_SkinNames[g_TotalSkins] = "Car Mechanic";
            case 118: g_SkinNames[g_TotalSkins] = "Car Mechanic";
            case 119: g_SkinNames[g_TotalSkins] = "Car Mechanic";
            case 120: g_SkinNames[g_TotalSkins] = "Pimp";
            case 121: g_SkinNames[g_TotalSkins] = "Pimp";
            case 122: g_SkinNames[g_TotalSkins] = "Pimp";
            case 123: g_SkinNames[g_TotalSkins] = "Pimp";
            case 124: g_SkinNames[g_TotalSkins] = "Pimp";
            case 125: g_SkinNames[g_TotalSkins] = "Clown";
            case 126: g_SkinNames[g_TotalSkins] = "Clown";
            case 127: g_SkinNames[g_TotalSkins] = "Clown";
            case 128: g_SkinNames[g_TotalSkins] = "Clown";
            case 129: g_SkinNames[g_TotalSkins] = "Clown";
            case 130: g_SkinNames[g_TotalSkins] = "Jogger";
            case 131: g_SkinNames[g_TotalSkins] = "Jogger";
            case 132: g_SkinNames[g_TotalSkins] = "Jogger";
            case 133: g_SkinNames[g_TotalSkins] = "Jogger";
            case 134: g_SkinNames[g_TotalSkins] = "Jogger";
            case 135: g_SkinNames[g_TotalSkins] = "Nervous Bob";
            case 136: g_SkinNames[g_TotalSkins] = "Nervous Bob";
            case 137: g_SkinNames[g_TotalSkins] = "Nervous Bob";
            case 138: g_SkinNames[g_TotalSkins] = "Nervous Bob";
            case 139: g_SkinNames[g_TotalSkins] = "Nervous Bob";
            case 140: g_SkinNames[g_TotalSkins] = "Homeless";
            case 141: g_SkinNames[g_TotalSkins] = "Homeless";
            case 142: g_SkinNames[g_TotalSkins] = "Homeless";
            case 143: g_SkinNames[g_TotalSkins] = "Homeless";
            case 144: g_SkinNames[g_TotalSkins] = "Homeless";
            case 145: g_SkinNames[g_TotalSkins] = "Businesswoman";
            case 146: g_SkinNames[g_TotalSkins] = "Businesswoman";
            case 147: g_SkinNames[g_TotalSkins] = "Businesswoman";
            case 148: g_SkinNames[g_TotalSkins] = "Businesswoman";
            case 149: g_SkinNames[g_TotalSkins] = "Businesswoman";
            case 150: g_SkinNames[g_TotalSkins] = "Skater";
            case 151: g_SkinNames[g_TotalSkins] = "Skater";
            case 152: g_SkinNames[g_TotalSkins] = "Skater";
            case 153: g_SkinNames[g_TotalSkins] = "Skater";
            case 154: g_SkinNames[g_TotalSkins] = "Skater";
            case 155: g_SkinNames[g_TotalSkins] = "Prisoner";
            case 156: g_SkinNames[g_TotalSkins] = "Prisoner";
            case 157: g_SkinNames[g_TotalSkins] = "Prisoner";
            case 158: g_SkinNames[g_TotalSkins] = "Prisoner";
            case 159: g_SkinNames[g_TotalSkins] = "Prisoner";
            case 160: g_SkinNames[g_TotalSkins] = "Valet";
            case 161: g_SkinNames[g_TotalSkins] = "Valet";
            case 162: g_SkinNames[g_TotalSkins] = "Valet";
            case 163: g_SkinNames[g_TotalSkins] = "Valet";
            case 164: g_SkinNames[g_TotalSkins] = "Valet";
            case 165: g_SkinNames[g_TotalSkins] = "Migrant";
            case 166: g_SkinNames[g_TotalSkins] = "Migrant";
            case 167: g_SkinNames[g_TotalSkins] = "Migrant";
            case 168: g_SkinNames[g_TotalSkins] = "Migrant";
            case 169: g_SkinNames[g_TotalSkins] = "Migrant";
            case 170: g_SkinNames[g_TotalSkins] = "Ranger";
            case 171: g_SkinNames[g_TotalSkins] = "Ranger";
            case 172: g_SkinNames[g_TotalSkins] = "Ranger";
            case 173: g_SkinNames[g_TotalSkins] = "Ranger";
            case 174: g_SkinNames[g_TotalSkins] = "Ranger";
            case 175: g_SkinNames[g_TotalSkins] = "Wrestler";
            case 176: g_SkinNames[g_TotalSkins] = "Wrestler";
            case 177: g_SkinNames[g_TotalSkins] = "Wrestler";
            case 178: g_SkinNames[g_TotalSkins] = "Wrestler";
            case 179: g_SkinNames[g_TotalSkins] = "Wrestler";
            case 180: g_SkinNames[g_TotalSkins] = "Cholo";
            case 181: g_SkinNames[g_TotalSkins] = "Cholo";
            case 182: g_SkinNames[g_TotalSkins] = "Cholo";
            case 183: g_SkinNames[g_TotalSkins] = "Cholo";
            case 184: g_SkinNames[g_TotalSkins] = "Cholo";
            case 185: g_SkinNames[g_TotalSkins] = "Golfer";
            case 186: g_SkinNames[g_TotalSkins] = "Golfer";
            case 187: g_SkinNames[g_TotalSkins] = "Golfer";
            case 188: g_SkinNames[g_TotalSkins] = "Golfer";
            case 189: g_SkinNames[g_TotalSkins] = "Golfer";
            case 190: g_SkinNames[g_TotalSkins] = "Golfer";
            case 191: g_SkinNames[g_TotalSkins] = "Golfer";
            case 192: g_SkinNames[g_TotalSkins] = "Golfer";
            case 193: g_SkinNames[g_TotalSkins] = "Golfer";
            case 194: g_SkinNames[g_TotalSkins] = "Golfer";
            case 195: g_SkinNames[g_TotalSkins] = "Golfer";
            case 196: g_SkinNames[g_TotalSkins] = "Golfer";
            case 197: g_SkinNames[g_TotalSkins] = "Golfer";
            case 198: g_SkinNames[g_TotalSkins] = "Golfer";
            case 199: g_SkinNames[g_TotalSkins] = "Golfer";
            case 200: g_SkinNames[g_TotalSkins] = "Croupier";
            case 201: g_SkinNames[g_TotalSkins] = "Croupier";
            case 202: g_SkinNames[g_TotalSkins] = "Croupier";
            case 203: g_SkinNames[g_TotalSkins] = "Croupier";
            case 204: g_SkinNames[g_TotalSkins] = "Croupier";
            case 205: g_SkinNames[g_TotalSkins] = "Dealer";
            case 206: g_SkinNames[g_TotalSkins] = "Dealer";
            case 207: g_SkinNames[g_TotalSkins] = "Dealer";
            case 208: g_SkinNames[g_TotalSkins] = "Dealer";
            case 209: g_SkinNames[g_TotalSkins] = "Dealer";
            case 210: g_SkinNames[g_TotalSkins] = "Dealer";
            case 211: g_SkinNames[g_TotalSkins] = "Dealer";
            case 212: g_SkinNames[g_TotalSkins] = "Dealer";
            case 213: g_SkinNames[g_TotalSkins] = "Dealer";
            case 214: g_SkinNames[g_TotalSkins] = "Dealer";
            case 215: g_SkinNames[g_TotalSkins] = "Convict";
            case 216: g_SkinNames[g_TotalSkins] = "Convict";
            case 217: g_SkinNames[g_TotalSkins] = "Convict";
            case 218: g_SkinNames[g_TotalSkins] = "Convict";
            case 219: g_SkinNames[g_TotalSkins] = "Convict";
            case 220: g_SkinNames[g_TotalSkins] = "Casino Staff";
            case 221: g_SkinNames[g_TotalSkins] = "Casino Staff";
            case 222: g_SkinNames[g_TotalSkins] = "Casino Staff";
            case 223: g_SkinNames[g_TotalSkins] = "Casino Staff";
            case 224: g_SkinNames[g_TotalSkins] = "Casino Staff";
            case 225: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 226: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 227: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 228: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 229: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 230: g_SkinNames[g_TotalSkins] = "Girlfriend";
            case 231: g_SkinNames[g_TotalSkins] = "Girlfriend";
            case 232: g_SkinNames[g_TotalSkins] = "Girlfriend";
            case 233: g_SkinNames[g_TotalSkins] = "Girlfriend";
            case 234: g_SkinNames[g_TotalSkins] = "Girlfriend";
            case 235: g_SkinNames[g_TotalSkins] = "Pool Player";
            case 236: g_SkinNames[g_TotalSkins] = "Pool Player";
            case 237: g_SkinNames[g_TotalSkins] = "Pool Player";
            case 238: g_SkinNames[g_TotalSkins] = "Pool Player";
            case 239: g_SkinNames[g_TotalSkins] = "Pool Player";
            case 240: g_SkinNames[g_TotalSkins] = "Farmer";
            case 241: g_SkinNames[g_TotalSkins] = "Farmer";
            case 242: g_SkinNames[g_TotalSkins] = "Farmer";
            case 243: g_SkinNames[g_TotalSkins] = "Farmer";
            case 244: g_SkinNames[g_TotalSkins] = "Farmer";
            case 245: g_SkinNames[g_TotalSkins] = "Croupier";
            case 246: g_SkinNames[g_TotalSkins] = "Croupier";
            case 247: g_SkinNames[g_TotalSkins] = "Croupier";
            case 248: g_SkinNames[g_TotalSkins] = "Croupier";
            case 249: g_SkinNames[g_TotalSkins] = "Croupier";
            case 250: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 251: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 252: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 253: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 254: g_SkinNames[g_TotalSkins] = "Prostitute";
            case 255: g_SkinNames[g_TotalSkins] = "Farmer";
            case 256: g_SkinNames[g_TotalSkins] = "Farmer";
            case 257: g_SkinNames[g_TotalSkins] = "Farmer";
            case 258: g_SkinNames[g_TotalSkins] = "Farmer";
            case 259: g_SkinNames[g_TotalSkins] = "Farmer";
            case 260: g_SkinNames[g_TotalSkins] = "Farmer";
            case 261: g_SkinNames[g_TotalSkins] = "Farmer";
            case 262: g_SkinNames[g_TotalSkins] = "Farmer";
            case 263: g_SkinNames[g_TotalSkins] = "Farmer";
            case 264: g_SkinNames[g_TotalSkins] = "Farmer";
            case 265: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 266: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 267: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 268: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 269: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 270: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 271: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 272: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 273: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 274: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 275: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 276: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 277: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 278: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 279: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 280: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 281: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 282: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 283: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 284: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 285: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 286: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 287: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 288: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 289: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 290: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 291: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 292: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 293: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 294: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 295: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 296: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 297: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 298: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            case 299: g_SkinNames[g_TotalSkins] = "Madd Dogg";
            default: format(g_SkinNames[g_TotalSkins], 32, "Skin %d", skinid);
        }
        g_TotalSkins++;
    }
    printf("[Ƥ��ϵͳ] �Ѽ��� %d ��Ƥ��", g_TotalSkins);
}

// ---------- �����˵����복���˵���ȫ��ͬ��----------
stock CreatePlayerMenu(playerid) {
    // ������
    g_MenuBackground[playerid] = CreatePlayerTextDraw(playerid, 85.0, 75.0, "_");
    PlayerTextDrawTextSize(playerid, g_MenuBackground[playerid], 480.0, 300.0);
    PlayerTextDrawUseBox(playerid, g_MenuBackground[playerid], 1);
    PlayerTextDrawBoxColor(playerid, g_MenuBackground[playerid], 0x000000CC);
    PlayerTextDrawFont(playerid, g_MenuBackground[playerid], 0);
    PlayerTextDrawAlignment(playerid, g_MenuBackground[playerid], 1);
    
    // Ƥ�����ӣ�3�� x 7�У�
    new Float:x = 100.0, Float:y = 95.0;
    new Float:stepX = 62.0, Float:stepY = 70.0;
    new Float:previewSize = 50.0;
    
    for(new row = 0; row < 3; row++) {
        for(new col = 0; col < 7; col++) {
            new idx = row * 7 + col;
            g_SkinTD[playerid][idx] = CreatePlayerTextDraw(playerid, x + col*stepX, y + row*stepY, "_");
            PlayerTextDrawFont(playerid, g_SkinTD[playerid][idx], TEXT_DRAW_FONT_MODEL_PREVIEW);
            PlayerTextDrawTextSize(playerid, g_SkinTD[playerid][idx], previewSize, previewSize);
            PlayerTextDrawAlignment(playerid, g_SkinTD[playerid][idx], 2);
            PlayerTextDrawBackgroundColor(playerid, g_SkinTD[playerid][idx], 0x000000FF);
            PlayerTextDrawSetSelectable(playerid, g_SkinTD[playerid][idx], 1);
            PlayerTextDrawSetPreviewModel(playerid, g_SkinTD[playerid][idx], 0);  // Ĭ����ʾCJ
            PlayerTextDrawSetPreviewRot(playerid, g_SkinTD[playerid][idx], 0.0, 0.0, 30.0, 1.0);
        }
    }
    
    // ��ҳ��ť
    g_PrevTD[playerid] = CreatePlayerTextDraw(playerid, 215.0, 345.0, "��һҳ");
    PlayerTextDrawFont(playerid, g_PrevTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_PrevTD[playerid], 0.4, 1.2);
    PlayerTextDrawColor(playerid, g_PrevTD[playerid], 0xFFFFFFFF);
    PlayerTextDrawSetSelectable(playerid, g_PrevTD[playerid], 1);
    
    g_NextTD[playerid] = CreatePlayerTextDraw(playerid, 345.0, 345.0, "��һҳ");
    PlayerTextDrawFont(playerid, g_NextTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_NextTD[playerid], 0.4, 1.2);
    PlayerTextDrawColor(playerid, g_NextTD[playerid], 0xFFFFFFFF);
    PlayerTextDrawSetSelectable(playerid, g_NextTD[playerid], 1);
    
    // ҳ����Ϣ
    g_PageInfoTD[playerid] = CreatePlayerTextDraw(playerid, 280.0, 375.0, "�� 1/1 ҳ");
    PlayerTextDrawFont(playerid, g_PageInfoTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_PageInfoTD[playerid], 0.3, 1.0);
    PlayerTextDrawColor(playerid, g_PageInfoTD[playerid], 0xFFFF00FF);
}

// ---------- ˢ�²˵����� ----------
stock RefreshPlayerMenu(playerid) {
    if(!g_MenuOpen[playerid]) return;
    
    new start = g_CurrentPage[playerid] * SKINS_PER_PAGE;
    new totalPages = (g_TotalSkins + SKINS_PER_PAGE - 1) / SKINS_PER_PAGE;
    
    for(new i = 0; i < SKINS_PER_PAGE; i++) {
        new idx = start + i;
        if(idx < g_TotalSkins) {
            new model = g_SkinModels[idx];
            new name[32];
            format(name, 32, g_SkinNames[idx]);
            
            PlayerTextDrawSetPreviewModel(playerid, g_SkinTD[playerid][i], model);
            PlayerTextDrawSetString(playerid, g_SkinTD[playerid][i], name);
            PlayerTextDrawShow(playerid, g_SkinTD[playerid][i]);
        } else {
            PlayerTextDrawHide(playerid, g_SkinTD[playerid][i]);
        }
    }
    
    new pageInfo[32];
    format(pageInfo, 32, "�� %d/%d ҳ", g_CurrentPage[playerid]+1, totalPages);
    PlayerTextDrawSetString(playerid, g_PageInfoTD[playerid], pageInfo);
    
    PlayerTextDrawShow(playerid, g_MenuBackground[playerid]);
    PlayerTextDrawShow(playerid, g_PrevTD[playerid]);
    PlayerTextDrawShow(playerid, g_NextTD[playerid]);
    PlayerTextDrawShow(playerid, g_PageInfoTD[playerid]);
    
    SelectTextDraw(playerid, 0xFFFFFFFF);
}

// ---------- ��/�رղ˵� ----------
stock OpenSkinMenu(playerid) {
    if(g_MenuOpen[playerid]) return;
    g_MenuOpen[playerid] = 1;
    g_CurrentPage[playerid] = 0;
    RefreshPlayerMenu(playerid);
}

stock CloseSkinMenu(playerid) {
    if(!g_MenuOpen[playerid]) return;
    g_MenuOpen[playerid] = 0;
    CancelSelectTextDraw(playerid);
    
    for(new i = 0; i < SKINS_PER_PAGE; i++) {
        PlayerTextDrawHide(playerid, g_SkinTD[playerid][i]);
    }
    PlayerTextDrawHide(playerid, g_PrevTD[playerid]);
    PlayerTextDrawHide(playerid, g_NextTD[playerid]);
    PlayerTextDrawHide(playerid, g_PageInfoTD[playerid]);
    PlayerTextDrawHide(playerid, g_MenuBackground[playerid]);
}

// ---------- ���� ----------
stock SetPlayerSkinSafe(playerid, skinid) {
    if(skinid < 0 || skinid >= MAX_SKINS) {
        SendClientMessage(playerid, 0xFF6666FF, "[ϵͳ] ��ЧƤ��ID�������� 0-311 ֮������֡�");
        return 0;
    }
    SetPlayerSkin(playerid, skinid);
    new msg[128];
    format(msg, sizeof(msg), "? �Ѹ���Ƥ��Ϊ: %s (ID:%d) ?", g_SkinNames[skinid], skinid);
    SendClientMessage(playerid, 0x66FF66FF, msg);
    return 1;
}

// ---------- ����� ----------
public OnPlayerCommandText(playerid, cmdtext[]) {
    if(strcmp(cmdtext, "/skin", true, 5) == 0) {
        new params[128];
        if(strlen(cmdtext) > 6)
            strmid(params, cmdtext, 6, strlen(cmdtext));
        else
            params[0] = 0;
        
        if(strlen(params) == 0) {
            SendClientMessage(playerid, 0xFFAA66FF, "ʹ�÷���: /skin [ID] �� /skin list");
            return 1;
        }
        
        if(strcmp(params, "list", true) == 0) {
            if(g_MenuOpen[playerid]) CloseSkinMenu(playerid);
            else OpenSkinMenu(playerid);
            return 1;
        }
        
        new skinid = strval(params);
        SetPlayerSkinSafe(playerid, skinid);
        return 1;
    }
    return 0;
}

// ---------- �ص����� ----------
public OnFilterScriptInit() {
    print("\n======================================");
    print("   ͼ�λ�Ƥ���˵��Ѽ��أ���ԭ����3Dģ��Ԥ����");
    print("   ����: /skin [ID] �� /skin list");
    print("======================================\n");
    LoadSkinData();
    return 1;
}

public OnFilterScriptExit() {
    for(new i=0; i<MAX_PLAYERS; i++) {
        if(IsPlayerConnected(i)) {
            CloseSkinMenu(i);
            for(new j=0; j<SKINS_PER_PAGE; j++) {
                PlayerTextDrawDestroy(i, g_SkinTD[i][j]);
            }
            PlayerTextDrawDestroy(i, g_PrevTD[i]);
            PlayerTextDrawDestroy(i, g_NextTD[i]);
            PlayerTextDrawDestroy(i, g_PageInfoTD[i]);
            PlayerTextDrawDestroy(i, g_MenuBackground[i]);
        }
    }
    print("ͼ�λ�Ƥ���˵���ж��");
    return 1;
}

public OnPlayerConnect(playerid) {
    g_MenuOpen[playerid] = 0;
    g_CurrentPage[playerid] = 0;
    CreatePlayerMenu(playerid);
    SendClientMessage(playerid, 0x00FFAAFF, "��ӭ������ /skin list ��ͼ�λ�Ƥ���˵����� /skin [ID] ֱ�ӻ�����");
    return 1;
}

public OnPlayerDisconnect(playerid, reason) {
    CloseSkinMenu(playerid);
    for(new j=0; j<SKINS_PER_PAGE; j++) {
        PlayerTextDrawDestroy(playerid, g_SkinTD[playerid][j]);
    }
    PlayerTextDrawDestroy(playerid, g_PrevTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_NextTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_PageInfoTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_MenuBackground[playerid]);
    return 1;
}

public OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid) {
    if(!g_MenuOpen[playerid]) return 0;
    
    if(playertextid == g_PrevTD[playerid]) {
        if(g_CurrentPage[playerid] > 0) {
            g_CurrentPage[playerid]--;
            RefreshPlayerMenu(playerid);
        }
        return 1;
    }
    else if(playertextid == g_NextTD[playerid]) {
        new totalPages = (g_TotalSkins + SKINS_PER_PAGE - 1) / SKINS_PER_PAGE;
        if(g_CurrentPage[playerid] < totalPages - 1) {
            g_CurrentPage[playerid]++;
            RefreshPlayerMenu(playerid);
        }
        return 1;
    }
    else {
        for(new i=0; i<SKINS_PER_PAGE; i++) {
            if(playertextid == g_SkinTD[playerid][i]) {
                new skinid = g_CurrentPage[playerid] * SKINS_PER_PAGE + i;
                if(skinid < g_TotalSkins) {
                    SetPlayerSkinSafe(playerid, skinid);
                    CloseSkinMenu(playerid);
                }
                break;
            }
        }
        return 1;
    }
}

public OnPlayerCancelSelectTextDraw(playerid) {
    if(g_MenuOpen[playerid]) {
        CloseSkinMenu(playerid);
    }
    return 1;
}