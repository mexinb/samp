// ============================================================
// �ļ�: car.pwn
// ����: ȫ�ؾ�ϵͳ + ͼ�λ�ѡ���˵����ֻ��Ż���
// ����: /c [ID/����] [��ɫ1] [��ɫ2]  |  /c list
// ����: SA-MP 0.3.7+
// ============================================================

#include <a_samp>

// ---------- ���� ----------
#if !defined MAX_VEHICLES
    #define MAX_VEHICLES         612
#endif

#define VEHICLES_PER_PAGE    21

// ---------- �������� ----------
enum VehicleInfo {
    vModel,
    vName[32]
}
new g_Vehicles[MAX_VEHICLES][VehicleInfo];
new g_TotalVehicles = 0;
new VehicleNames[612][32];

// �������
new g_CurrentPage[MAX_PLAYERS];
new g_MenuOpen[MAX_PLAYERS];
new PlayerText:g_VehicleTD[MAX_PLAYERS][VEHICLES_PER_PAGE];
new PlayerText:g_PrevTD[MAX_PLAYERS];
new PlayerText:g_NextTD[MAX_PLAYERS];
new PlayerText:g_PageInfoTD[MAX_PLAYERS];
new PlayerText:g_MenuBackground[MAX_PLAYERS];

// ---------- forward ���� ----------
forward OnPlayerCancelSelectTextDraw(playerid);

// ---------- strtok ��������� sscanf��----------
new g_strtok_idx;
stock strtok(const string[], &index, dest[], max_len, bool:trim_spaces = true) {
    new len = strlen(string);
    new pos = index;
    while(pos < len && string[pos] == ' ') pos++;
    if(pos >= len) {
        dest[0] = 0;
        index = len;
        return 0;
    }
    new start = pos;
    while(pos < len && string[pos] != ' ') pos++;
    new end = pos;
    new copy_len = (end - start) > (max_len-1) ? (max_len-1) : (end - start);
    strmid(dest, string, start, start + copy_len);
    dest[copy_len] = 0;
    index = pos;
    return 1;
}

// ---------- �������Ƽ��أ�ȫӢ�ģ�400-611��----------
stock LoadAllVehicleNames() {
    // �������
    for(new i=0; i<612; i++) VehicleNames[i][0] = 0;

    // ����Ӣ�����ƣ����� SA-MP �ٷ����ݣ�
    VehicleNames[400] = "Landstalker";
    VehicleNames[401] = "Bravura";
    VehicleNames[402] = "Buffalo";
    VehicleNames[403] = "Linerunner";
    VehicleNames[404] = "Perennial";
    VehicleNames[405] = "Sentinel";
    VehicleNames[406] = "Dumper";
    VehicleNames[407] = "Firetruck";
    VehicleNames[408] = "Trashmaster";
    VehicleNames[409] = "Stretch";
    VehicleNames[410] = "Manana";
    VehicleNames[411] = "Infernus";
    VehicleNames[412] = "Voodoo";
    VehicleNames[413] = "Pony";
    VehicleNames[414] = "Mule";
    VehicleNames[415] = "Cheetah";
    VehicleNames[416] = "Ambulance";
    VehicleNames[417] = "Leviathan";
    VehicleNames[418] = "Moonbeam";
    VehicleNames[419] = "Esperanto";
    VehicleNames[420] = "Taxi";
    VehicleNames[421] = "Washington";
    VehicleNames[422] = "Bobcat";
    VehicleNames[423] = "Mr Whoopee";
    VehicleNames[424] = "BF Injection";
    VehicleNames[425] = "Hunter";
    VehicleNames[426] = "Premier";
    VehicleNames[427] = "Enforcer";
    VehicleNames[428] = "Securicar";
    VehicleNames[429] = "Banshee";
    VehicleNames[430] = "Predator";
    VehicleNames[431] = "Bus";
    VehicleNames[432] = "Rhino";
    VehicleNames[433] = "Barracks";
    VehicleNames[434] = "Hotknife";
    VehicleNames[435] = "Artict1";
    VehicleNames[436] = "Previon";
    VehicleNames[437] = "Coach";
    VehicleNames[438] = "Cabbie";
    VehicleNames[439] = "Stallion";
    VehicleNames[440] = "Rumpo";
    VehicleNames[441] = "RC Bandit";
    VehicleNames[442] = "Romero";
    VehicleNames[443] = "Packer";
    VehicleNames[444] = "Monster";
    VehicleNames[445] = "Admiral";
    VehicleNames[446] = "Squalo";
    VehicleNames[447] = "Seasparrow";
    VehicleNames[448] = "Pizzaboy";
    VehicleNames[449] = "Tram";
    VehicleNames[450] = "Artict2";
    VehicleNames[451] = "Turismo";
    VehicleNames[452] = "Speeder";
    VehicleNames[453] = "Reefer";
    VehicleNames[454] = "Tropic";
    VehicleNames[455] = "Flatbed";
    VehicleNames[456] = "Yankee";
    VehicleNames[457] = "Caddy";
    VehicleNames[458] = "Solair";
    VehicleNames[459] = "Berkley's RC Van";
    VehicleNames[460] = "Skimmer";
    VehicleNames[461] = "PCJ-600";
    VehicleNames[462] = "Faggio";
    VehicleNames[463] = "Freeway";
    VehicleNames[464] = "RC Baron";
    VehicleNames[465] = "RC Raider";
    VehicleNames[466] = "Glendale";
    VehicleNames[467] = "Oceanic";
    VehicleNames[468] = "Sanchez";
    VehicleNames[469] = "Sparrow";
    VehicleNames[470] = "Patriot";
    VehicleNames[471] = "Quad";
    VehicleNames[472] = "Coastguard";
    VehicleNames[473] = "Dinghy";
    VehicleNames[474] = "Hermes";
    VehicleNames[475] = "Sabre";
    VehicleNames[476] = "Rustler";
    VehicleNames[477] = "ZR-350";
    VehicleNames[478] = "Walton";
    VehicleNames[479] = "Regina";
    VehicleNames[480] = "Comet";
    VehicleNames[481] = "BMX";
    VehicleNames[482] = "Burrito";
    VehicleNames[483] = "Camper";
    VehicleNames[484] = "Marquis";
    VehicleNames[485] = "Baggage";
    VehicleNames[486] = "Dozer";
    VehicleNames[487] = "Maverick";
    VehicleNames[488] = "News Chopper";
    VehicleNames[489] = "Rancher";
    VehicleNames[490] = "FBI Rancher";
    VehicleNames[491] = "Virgo";
    VehicleNames[492] = "Greenwood";
    VehicleNames[493] = "Jetmax";
    VehicleNames[494] = "Hotring Racer";
    VehicleNames[495] = "Sandking";
    VehicleNames[496] = "Blista Compact";
    VehicleNames[497] = "Police Maverick";
    VehicleNames[498] = "Boxville";
    VehicleNames[499] = "Benson";
    VehicleNames[500] = "Mesa";
    VehicleNames[501] = "RC Goblin";
    VehicleNames[502] = "Hotring Racer 2";
    VehicleNames[503] = "Hotring Racer 3";
    VehicleNames[504] = "Bloodring Banger";
    VehicleNames[505] = "Rancher Lure";
    VehicleNames[506] = "Super GT";
    VehicleNames[507] = "Elegant";
    VehicleNames[508] = "Journey";
    VehicleNames[509] = "Bike";
    VehicleNames[510] = "Mountain Bike";
    VehicleNames[511] = "Beagle";
    VehicleNames[512] = "Cropduster";
    VehicleNames[513] = "Stuntplane";
    VehicleNames[514] = "Tanker";
    VehicleNames[515] = "Roadtrain";
    VehicleNames[516] = "Nebula";
    VehicleNames[517] = "Majestic";
    VehicleNames[518] = "Buccaneer";
    VehicleNames[519] = "Shamal";
    VehicleNames[520] = "Hydra";
    VehicleNames[521] = "FCR-900";
    VehicleNames[522] = "NRG-500";
    VehicleNames[523] = "HPV1000";
    VehicleNames[524] = "Cement Truck";
    VehicleNames[525] = "Tow Truck";
    VehicleNames[526] = "Fortune";
    VehicleNames[527] = "Cadrona";
    VehicleNames[528] = "FBI Truck";
    VehicleNames[529] = "Willard";
    VehicleNames[530] = "Forklift";
    VehicleNames[531] = "Tractor";
    VehicleNames[532] = "Combine";
    VehicleNames[533] = "Feltzer";
    VehicleNames[534] = "Remington";
    VehicleNames[535] = "Slamvan";
    VehicleNames[536] = "Blade";
    VehicleNames[537] = "Freight";
    VehicleNames[538] = "Streak";
    VehicleNames[539] = "Vortex";
    VehicleNames[540] = "Vincent";
    VehicleNames[541] = "Bullet";
    VehicleNames[542] = "Clover";
    VehicleNames[543] = "Sadler";
    VehicleNames[544] = "Firetruck";
    VehicleNames[545] = "Hustler";
    VehicleNames[546] = "Intruder";
    VehicleNames[547] = "Primo";
    VehicleNames[548] = "Cargobob";
    VehicleNames[549] = "Tampa";
    VehicleNames[550] = "Sunrise";
    VehicleNames[551] = "Merit";
    VehicleNames[552] = "Utility Van";
    VehicleNames[553] = "Nevada";
    VehicleNames[554] = "Yosemite";
    VehicleNames[555] = "Windsor";
    VehicleNames[556] = "Monster A";
    VehicleNames[557] = "Monster B";
    VehicleNames[558] = "Uranus";
    VehicleNames[559] = "Jester";
    VehicleNames[560] = "Sultan";
    VehicleNames[561] = "Stratum";
    VehicleNames[562] = "Elegy";
    VehicleNames[563] = "Raindance";
    VehicleNames[564] = "RC Tiger";
    VehicleNames[565] = "Flash";
    VehicleNames[566] = "Tahoma";
    VehicleNames[567] = "Savanna";
    VehicleNames[568] = "Bandito";
    VehicleNames[569] = "Freight Flat";
    VehicleNames[570] = "Streak Carriage";
    VehicleNames[571] = "Kart";
    VehicleNames[572] = "Mower";
    VehicleNames[573] = "Dune";
    VehicleNames[574] = "Sweeper";
    VehicleNames[575] = "Broadway";
    VehicleNames[576] = "Tornado";
    VehicleNames[577] = "AT-400";
    VehicleNames[578] = "DFT-30";
    VehicleNames[579] = "Huntley";
    VehicleNames[580] = "Stafford";
    VehicleNames[581] = "BF-400";
    VehicleNames[582] = "Newsvan";
    VehicleNames[583] = "Tug";
    VehicleNames[584] = "Petrol Tanker";
    VehicleNames[585] = "Emperor";
    VehicleNames[586] = "Wayfarer";
    VehicleNames[587] = "Euros";
    VehicleNames[588] = "Hotdog";
    VehicleNames[589] = "Club";
    VehicleNames[590] = "Boxville 2";
    VehicleNames[591] = "Boxville 3";
    VehicleNames[592] = "Andromada";
    VehicleNames[593] = "Dodo";
    VehicleNames[594] = "RC Cam";
    VehicleNames[595] = "Launch";
    VehicleNames[596] = "Police Car (LSPD)";
    VehicleNames[597] = "Police Car (SFPD)";
    VehicleNames[598] = "Police Car (LVPD)";
    VehicleNames[599] = "Police Ranger";
    VehicleNames[600] = "Picador";
    VehicleNames[601] = "S.W.A.T. Van";
    VehicleNames[602] = "Alpha";
    VehicleNames[603] = "Phoenix";
    VehicleNames[604] = "Glendale Shit";
    VehicleNames[605] = "Sadler Shit";
    VehicleNames[606] = "Baggage Trailer A";
    VehicleNames[607] = "Baggage Trailer B";
    VehicleNames[608] = "Tug Stairs";
    VehicleNames[609] = "Boxville";
    VehicleNames[610] = "Farm Trailer";
    VehicleNames[611] = "Utility Trailer";
}

// ---------- �������г�����ȫ���б� ----------
stock LoadAllVehicles() {
    g_TotalVehicles = 0;
    for(new model=400; model<=611; model++) {
        if(VehicleNames[model][0]) {
            g_Vehicles[g_TotalVehicles][vModel] = model;
            format(g_Vehicles[g_TotalVehicles][vName], 32, VehicleNames[model]);
            g_TotalVehicles++;
        }
    }
    printf("[����ϵͳ] �Ѽ��� %d ���ؾ�", g_TotalVehicles);
}

// ---------- �����������������Ʋ���ģ��ID ----------
stock FindModelByName(const name[]) {
    for(new i=0; i<g_TotalVehicles; i++) {
        if(strcmp(g_Vehicles[i][vName], name, true) == 0)
            return g_Vehicles[i][vModel];
    }
    return -1;
}

// ---------- �����˵����ֻ��Ż���λ��΢����----------
stock CreatePlayerMenu(playerid) {
    // ������
    g_MenuBackground[playerid] = CreatePlayerTextDraw(playerid, 85.0, 75.0, "_");
    PlayerTextDrawTextSize(playerid, g_MenuBackground[playerid], 480.0, 300.0);
    PlayerTextDrawUseBox(playerid, g_MenuBackground[playerid], 1);
    PlayerTextDrawBoxColor(playerid, g_MenuBackground[playerid], 0x000000CC);
    PlayerTextDrawFont(playerid, g_MenuBackground[playerid], 0);
    PlayerTextDrawAlignment(playerid, g_MenuBackground[playerid], 1);
    
    // ��������
    new Float:x = 100.0, Float:y = 95.0;
    new Float:stepX = 62.0, Float:stepY = 70.0;
    new Float:previewSize = 50.0;
    
    for(new row = 0; row < 3; row++) {
        for(new col = 0; col < 7; col++) {
            new idx = row * 7 + col;
            g_VehicleTD[playerid][idx] = CreatePlayerTextDraw(playerid, x + col*stepX, y + row*stepY, "_");
            PlayerTextDrawFont(playerid, g_VehicleTD[playerid][idx], TEXT_DRAW_FONT_MODEL_PREVIEW);
            PlayerTextDrawTextSize(playerid, g_VehicleTD[playerid][idx], previewSize, previewSize);
            PlayerTextDrawAlignment(playerid, g_VehicleTD[playerid][idx], 2);
            PlayerTextDrawBackgroundColor(playerid, g_VehicleTD[playerid][idx], 0x000000FF);
            PlayerTextDrawSetSelectable(playerid, g_VehicleTD[playerid][idx], 1);
            PlayerTextDrawSetPreviewModel(playerid, g_VehicleTD[playerid][idx], 411);
            PlayerTextDrawSetPreviewRot(playerid, g_VehicleTD[playerid][idx], -15.0, 0.0, 30.0, 1.0);
        }
    }
    
    // ��ҳ��ť
    g_PrevTD[playerid] = CreatePlayerTextDraw(playerid, 215.0, 345.0, "Prev");
    PlayerTextDrawFont(playerid, g_PrevTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_PrevTD[playerid], 0.4, 1.2);
    PlayerTextDrawColor(playerid, g_PrevTD[playerid], 0xFFFFFFFF);
    PlayerTextDrawSetSelectable(playerid, g_PrevTD[playerid], 1);
    
    g_NextTD[playerid] = CreatePlayerTextDraw(playerid, 345.0, 345.0, "Next");
    PlayerTextDrawFont(playerid, g_NextTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_NextTD[playerid], 0.4, 1.2);
    PlayerTextDrawColor(playerid, g_NextTD[playerid], 0xFFFFFFFF);
    PlayerTextDrawSetSelectable(playerid, g_NextTD[playerid], 1);
    
    // ҳ����Ϣ
    g_PageInfoTD[playerid] = CreatePlayerTextDraw(playerid, 280.0, 375.0, "Page 1/1");
    PlayerTextDrawFont(playerid, g_PageInfoTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_PageInfoTD[playerid], 0.3, 1.0);
    PlayerTextDrawColor(playerid, g_PageInfoTD[playerid], 0xFFFF00FF);
}

// ---------- ˢ�²˵����� ----------
stock RefreshPlayerMenu(playerid) {
    if(!g_MenuOpen[playerid]) return;
    
    new start = g_CurrentPage[playerid] * VEHICLES_PER_PAGE;
    new totalPages = (g_TotalVehicles + VEHICLES_PER_PAGE - 1) / VEHICLES_PER_PAGE;
    
    for(new i = 0; i < VEHICLES_PER_PAGE; i++) {
        new idx = start + i;
        if(idx < g_TotalVehicles) {
            new model = g_Vehicles[idx][vModel];
            new name[32];
            format(name, 32, g_Vehicles[idx][vName]);
            
            PlayerTextDrawSetPreviewModel(playerid, g_VehicleTD[playerid][i], model);
            PlayerTextDrawSetString(playerid, g_VehicleTD[playerid][i], name);
            PlayerTextDrawShow(playerid, g_VehicleTD[playerid][i]);
        } else {
            PlayerTextDrawHide(playerid, g_VehicleTD[playerid][i]);
        }
    }
    
    new pageInfo[32];
    format(pageInfo, 32, "Page %d/%d", g_CurrentPage[playerid]+1, totalPages);
    PlayerTextDrawSetString(playerid, g_PageInfoTD[playerid], pageInfo);
    
    PlayerTextDrawShow(playerid, g_MenuBackground[playerid]);
    PlayerTextDrawShow(playerid, g_PrevTD[playerid]);
    PlayerTextDrawShow(playerid, g_NextTD[playerid]);
    PlayerTextDrawShow(playerid, g_PageInfoTD[playerid]);
    
    SelectTextDraw(playerid, 0xFFFFFFFF);
}

// ---------- ��/�رղ˵� ----------
stock OpenVehicleMenu(playerid) {
    if(g_MenuOpen[playerid]) return;
    g_MenuOpen[playerid] = 1;
    g_CurrentPage[playerid] = 0;
    RefreshPlayerMenu(playerid);
}

stock CloseVehicleMenu(playerid) {
    if(!g_MenuOpen[playerid]) return;
    g_MenuOpen[playerid] = 0;
    CancelSelectTextDraw(playerid);
    
    for(new i = 0; i < VEHICLES_PER_PAGE; i++) {
        PlayerTextDrawHide(playerid, g_VehicleTD[playerid][i]);
    }
    PlayerTextDrawHide(playerid, g_PrevTD[playerid]);
    PlayerTextDrawHide(playerid, g_NextTD[playerid]);
    PlayerTextDrawHide(playerid, g_PageInfoTD[playerid]);
    PlayerTextDrawHide(playerid, g_MenuBackground[playerid]);
}

// ---------- ���ɳ�����֧����ɫ��----------
stock SpawnCarWithColor(playerid, modelid, color1 = -1, color2 = -1) {
    if(modelid < 400 || modelid > 611) {
        SendClientMessage(playerid, 0xFF6666FF, "[System] Invalid vehicle ID!");
        return 0;
    }
    
    new Float:x, Float:y, Float:z, Float:angle;
    GetPlayerPos(playerid, x, y, z);
    GetPlayerFacingAngle(playerid, angle);
    
    new Float:spawnX = x + (2.0 * floatsin(-angle, degrees));
    new Float:spawnY = y + (2.0 * floatcos(-angle, degrees));
    
    if(color1 == -1) color1 = random(256);
    if(color2 == -1) color2 = random(256);
    
    new vehicleid = CreateVehicle(modelid, spawnX, spawnY, z + 0.5, angle, color1, color2, -1);
    if(vehicleid == INVALID_VEHICLE_ID) return 0;
    
    SetVehicleNumberPlate(vehicleid, "CAR");
    SetVehicleVirtualWorld(vehicleid, GetPlayerVirtualWorld(playerid));
    LinkVehicleToInterior(vehicleid, GetPlayerInterior(playerid));
    PutPlayerInVehicle(playerid, vehicleid, 0);
    
    new vname[32];
    for(new i=0; i<g_TotalVehicles; i++) {
        if(g_Vehicles[i][vModel] == modelid) {
            format(vname, 32, g_Vehicles[i][vName]);
            break;
        }
    }
    
    new msg[128];
    format(msg, sizeof(msg), "Spawned %s (Color: %d, %d)", vname, color1, color2);
    SendClientMessage(playerid, 0x66FF66FF, msg);
    return 1;
}

// ---------- ����� ----------
public OnPlayerCommandText(playerid, cmdtext[]) {
    if(strcmp(cmdtext, "/c", true, 2) == 0) {
        new params[128];
        if(strlen(cmdtext) > 3)
            strmid(params, cmdtext, 3, strlen(cmdtext));
        else
            params[0] = 0;
        
        if(strlen(params) == 0) {
            SendClientMessage(playerid, 0xFFAA66FF, "Usage: /c [ID/name] [color1] [color2]  or  /c list");
            return 1;
        }
        
        if(strcmp(params, "list", true) == 0) {
            if(g_MenuOpen[playerid]) CloseVehicleMenu(playerid);
            else OpenVehicleMenu(playerid);
            return 1;
        }
        
        // ʹ�� strtok ��������
        new idx = 0;
        new arg1[32], arg2[8], arg3[8];
        new ok1 = strtok(params, idx, arg1, 32);
        new ok2 = strtok(params, idx, arg2, 8);
        new ok3 = strtok(params, idx, arg3, 8);
        
        new modelid = -1;
        new color1 = -1, color2 = -1;
        
        if(ok2) color1 = strval(arg2);
        if(ok3) color2 = strval(arg3);
        
        // �޸������жϣ���ȷ�ж��Ƿ�Ϊ����
        new is_number = 1;
        for(new i=0; arg1[i]; i++) {
            if(!('0' <= arg1[i] <= '9') && arg1[i] != '-') {
                is_number = 0;
                break;
            }
        }
        
        if(is_number) {
            modelid = strval(arg1);
        } else {
            modelid = FindModelByName(arg1);
        }
        
        if(modelid == -1) {
            SendClientMessage(playerid, 0xFF6666FF, "[System] Vehicle not found. Check name or ID.");
            return 1;
        }
        
        SpawnCarWithColor(playerid, modelid, color1, color2);
        return 1;
    }
    
    return 0;
}

// ---------- �ص����� ----------
public OnFilterScriptInit() {
    print("\n======================================");
    print("   Full Vehicle System + Graphical Menu");
    print("   Commands: /c [ID/name] [color1] [color2]  |  /c list");
    print("======================================\n");
    
    LoadAllVehicleNames();
    LoadAllVehicles();
    return 1;
}

public OnFilterScriptExit() {
    for(new i=0; i<MAX_PLAYERS; i++) {
        if(IsPlayerConnected(i)) {
            CloseVehicleMenu(i);
            for(new j=0; j<VEHICLES_PER_PAGE; j++) {
                PlayerTextDrawDestroy(i, g_VehicleTD[i][j]);
            }
            PlayerTextDrawDestroy(i, g_PrevTD[i]);
            PlayerTextDrawDestroy(i, g_NextTD[i]);
            PlayerTextDrawDestroy(i, g_PageInfoTD[i]);
            PlayerTextDrawDestroy(i, g_MenuBackground[i]);
        }
    }
    print("Full Vehicle System unloaded");
    return 1;
}

public OnPlayerConnect(playerid) {
    g_MenuOpen[playerid] = 0;
    g_CurrentPage[playerid] = 0;
    CreatePlayerMenu(playerid);
    SendClientMessage(playerid, 0x00FFAAFF, "Welcome! Use /c list for graphical menu, or /c [ID/name] to spawn.");
    return 1;
}

public OnPlayerDisconnect(playerid, reason) {
    CloseVehicleMenu(playerid);
    for(new j=0; j<VEHICLES_PER_PAGE; j++) {
        PlayerTextDrawDestroy(playerid, g_VehicleTD[playerid][j]);
    }
    PlayerTextDrawDestroy(playerid, g_PrevTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_NextTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_PageInfoTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_MenuBackground[playerid]);
    return 1;
}

public OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid) {
    if(!g_MenuOpen[playerid]) return 0;
    
    if(playertextid == g_PrevTD[playerid]) {
        if(g_CurrentPage[playerid] > 0) {
            g_CurrentPage[playerid]--;
            RefreshPlayerMenu(playerid);
        }
        return 1;
    }
    else if(playertextid == g_NextTD[playerid]) {
        new totalPages = (g_TotalVehicles + VEHICLES_PER_PAGE - 1) / VEHICLES_PER_PAGE;
        if(g_CurrentPage[playerid] < totalPages - 1) {
            g_CurrentPage[playerid]++;
            RefreshPlayerMenu(playerid);
        }
        return 1;
    }
    else {
        for(new i=0; i<VEHICLES_PER_PAGE; i++) {
            if(playertextid == g_VehicleTD[playerid][i]) {
                new idx = g_CurrentPage[playerid] * VEHICLES_PER_PAGE + i;
                if(idx < g_TotalVehicles) {
                    new model = g_Vehicles[idx][vModel];
                    SpawnCarWithColor(playerid, model, -1, -1);
                    CloseVehicleMenu(playerid);
                }
                break;
            }
        }
        return 1;
    }
}

public OnPlayerCancelSelectTextDraw(playerid) {
    if(g_MenuOpen[playerid]) {
        CloseVehicleMenu(playerid);
    }
    return 1;
}