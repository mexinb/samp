// ============================================================
// �ļ�: weapon.pwn
// ����: ͼ�λ������˵�����ȷ��3Dģ��Ԥ����
// ����: /w list
// ����: SA-MP 0.3.7+
// ============================================================

#include <a_samp>

#define WEAPONS_PER_PAGE    21

// �������ݽṹ
enum WeaponData {
    wWeaponID,      // ����ID (����GivePlayerWeapon)
    wModelID,       // ģ��ID (����Ԥ��)
    wName[32],
    wAmmo
}

new g_Weapons[][] = {
    // ��ս����
    {0, 0, "ȭͷ", 0},
    {1, 331, "ָ����", 0},
    {2, 333, "�߶������", 0},
    {3, 334, "����", 0},
    {4, 335, "С��", 0},
    {5, 336, "�����", 0},
    {6, 337, "����", 0},
    {7, 338, "̨���", 0},
    {8, 339, "��ʿ��", 0},
    {9, 341, "���", 0},
    
    // ��ǹ
    {22, 346, "��ǹ", 100},
    {23, 347, "������ǹ", 100},
    {24, 348, "ɳĮ֮ӥ", 100},
    
    // ����ǹ
    {25, 349, "����ǹ", 50},
    {26, 350, "�̹�����", 50},
    {27, 351, "ս������", 50},
    
    // ���ǹ
    {28, 352, "΢�ͳ��ǹ", 200},
    {29, 353, "MP5", 200},
    {32, 372, "TEC-9", 200},
    
    // ��ǹ
    {30, 355, "AK-47", 200},
    {31, 356, "M4", 200},
    
    // �ѻ�ǹ
    {33, 357, "�ѻ���ǹ", 50},
    {34, 358, "����", 50},
    
    // ��������
    {35, 359, "RPG", 20},
    {36, 360, "���Ͳ", 20},
    {37, 361, "����������", 200},
    {38, 362, "������", 500},
    
    // Ͷ������
    {16, 342, "����", 10},
    {17, 343, "ȼ��ƿ", 10},
    {18, 344, "������", 10},
    
    // ����
    {39, 363, "������˹", 10},
    {41, 364, "�����", 100},
    {42, 365, "�����", 100},
    {43, 366, "�����", 0},
    {44, 367, "ҹ�Ӿ�", 0},
    {45, 368, "�ȳ���", 0},
    {46, 369, "����ɡ", 0}
};

new g_TotalWeapons = sizeof(g_Weapons);

// �������
new g_CurrentPage[MAX_PLAYERS];
new g_MenuOpen[MAX_PLAYERS];
new PlayerText:g_WeaponTD[MAX_PLAYERS][WEAPONS_PER_PAGE];
new PlayerText:g_PrevTD[MAX_PLAYERS];
new PlayerText:g_NextTD[MAX_PLAYERS];
new PlayerText:g_PageInfoTD[MAX_PLAYERS];
new PlayerText:g_MenuBackground[MAX_PLAYERS];

forward OnPlayerCancelSelectTextDraw(playerid);

// ---------- �����˵� ----------
stock CreatePlayerMenu(playerid) {
    g_MenuBackground[playerid] = CreatePlayerTextDraw(playerid, 85.0, 75.0, "_");
    PlayerTextDrawTextSize(playerid, g_MenuBackground[playerid], 480.0, 300.0);
    PlayerTextDrawUseBox(playerid, g_MenuBackground[playerid], 1);
    PlayerTextDrawBoxColor(playerid, g_MenuBackground[playerid], 0x000000CC);
    PlayerTextDrawFont(playerid, g_MenuBackground[playerid], 0);
    PlayerTextDrawAlignment(playerid, g_MenuBackground[playerid], 1);
    
    new Float:x = 100.0, Float:y = 95.0;
    new Float:stepX = 62.0, Float:stepY = 70.0;
    new Float:previewSize = 50.0;
    
    for(new row = 0; row < 3; row++) {
        for(new col = 0; col < 7; col++) {
            new idx = row * 7 + col;
            g_WeaponTD[playerid][idx] = CreatePlayerTextDraw(playerid, x + col*stepX, y + row*stepY, "_");
            PlayerTextDrawFont(playerid, g_WeaponTD[playerid][idx], TEXT_DRAW_FONT_MODEL_PREVIEW);
            PlayerTextDrawTextSize(playerid, g_WeaponTD[playerid][idx], previewSize, previewSize);
            PlayerTextDrawAlignment(playerid, g_WeaponTD[playerid][idx], 2);
            PlayerTextDrawBackgroundColor(playerid, g_WeaponTD[playerid][idx], 0x000000FF);
            PlayerTextDrawSetSelectable(playerid, g_WeaponTD[playerid][idx], 1);
            PlayerTextDrawSetPreviewModel(playerid, g_WeaponTD[playerid][idx], 331);
            PlayerTextDrawSetPreviewRot(playerid, g_WeaponTD[playerid][idx], -15.0, 0.0, 30.0, 1.0);
        }
    }
    
    g_PrevTD[playerid] = CreatePlayerTextDraw(playerid, 215.0, 345.0, "��һҳ");
    PlayerTextDrawFont(playerid, g_PrevTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_PrevTD[playerid], 0.4, 1.2);
    PlayerTextDrawColor(playerid, g_PrevTD[playerid], 0xFFFFFFFF);
    PlayerTextDrawSetSelectable(playerid, g_PrevTD[playerid], 1);
    
    g_NextTD[playerid] = CreatePlayerTextDraw(playerid, 345.0, 345.0, "��һҳ");
    PlayerTextDrawFont(playerid, g_NextTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_NextTD[playerid], 0.4, 1.2);
    PlayerTextDrawColor(playerid, g_NextTD[playerid], 0xFFFFFFFF);
    PlayerTextDrawSetSelectable(playerid, g_NextTD[playerid], 1);
    
    g_PageInfoTD[playerid] = CreatePlayerTextDraw(playerid, 280.0, 375.0, "�� 1/1 ҳ");
    PlayerTextDrawFont(playerid, g_PageInfoTD[playerid], 1);
    PlayerTextDrawLetterSize(playerid, g_PageInfoTD[playerid], 0.3, 1.0);
    PlayerTextDrawColor(playerid, g_PageInfoTD[playerid], 0xFFFF00FF);
}

// ---------- ˢ�²˵� ----------
stock RefreshPlayerMenu(playerid) {
    if(!g_MenuOpen[playerid]) return;
    
    new start = g_CurrentPage[playerid] * WEAPONS_PER_PAGE;
    new totalPages = (g_TotalWeapons + WEAPONS_PER_PAGE - 1) / WEAPONS_PER_PAGE;
    
    for(new i = 0; i < WEAPONS_PER_PAGE; i++) {
        new idx = start + i;
        if(idx < g_TotalWeapons) {
            new model = g_Weapons[idx][wModelID];
            new name[32];
            format(name, 32, g_Weapons[idx][wName]);
            
            PlayerTextDrawSetPreviewModel(playerid, g_WeaponTD[playerid][i], model);
            PlayerTextDrawSetString(playerid, g_WeaponTD[playerid][i], name);
            PlayerTextDrawShow(playerid, g_WeaponTD[playerid][i]);
        } else {
            PlayerTextDrawHide(playerid, g_WeaponTD[playerid][i]);
        }
    }
    
    new pageInfo[32];
    format(pageInfo, 32, "�� %d/%d ҳ", g_CurrentPage[playerid]+1, totalPages);
    PlayerTextDrawSetString(playerid, g_PageInfoTD[playerid], pageInfo);
    
    PlayerTextDrawShow(playerid, g_MenuBackground[playerid]);
    PlayerTextDrawShow(playerid, g_PrevTD[playerid]);
    PlayerTextDrawShow(playerid, g_NextTD[playerid]);
    PlayerTextDrawShow(playerid, g_PageInfoTD[playerid]);
    
    SelectTextDraw(playerid, 0xFFFFFFFF);
}

// ---------- ��/�رղ˵� ----------
stock OpenWeaponMenu(playerid) {
    if(g_MenuOpen[playerid]) return;
    g_MenuOpen[playerid] = 1;
    g_CurrentPage[playerid] = 0;
    RefreshPlayerMenu(playerid);
}

stock CloseWeaponMenu(playerid) {
    if(!g_MenuOpen[playerid]) return;
    g_MenuOpen[playerid] = 0;
    CancelSelectTextDraw(playerid);
    
    for(new i = 0; i < WEAPONS_PER_PAGE; i++) {
        PlayerTextDrawHide(playerid, g_WeaponTD[playerid][i]);
    }
    PlayerTextDrawHide(playerid, g_PrevTD[playerid]);
    PlayerTextDrawHide(playerid, g_NextTD[playerid]);
    PlayerTextDrawHide(playerid, g_PageInfoTD[playerid]);
    PlayerTextDrawHide(playerid, g_MenuBackground[playerid]);
}

// ---------- ����� ----------
public OnPlayerCommandText(playerid, cmdtext[]) {
    if(strcmp(cmdtext, "/w list", true) == 0) {
        if(g_MenuOpen[playerid]) CloseWeaponMenu(playerid);
        else OpenWeaponMenu(playerid);
        return 1;
    }
    return 0;
}

// ---------- �ص����� ----------
public OnFilterScriptInit() {
    print("\n======================================");
    print("   ͼ�λ������˵��Ѽ��أ���ȷģ��Ԥ����");
    print("   ����: /w list");
    print("======================================\n");
    printf("[����ϵͳ] �Ѽ��� %d ������", g_TotalWeapons);
    return 1;
}

public OnFilterScriptExit() {
    for(new i=0; i<MAX_PLAYERS; i++) {
        if(IsPlayerConnected(i)) {
            CloseWeaponMenu(i);
            for(new j=0; j<WEAPONS_PER_PAGE; j++) {
                PlayerTextDrawDestroy(i, g_WeaponTD[i][j]);
            }
            PlayerTextDrawDestroy(i, g_PrevTD[i]);
            PlayerTextDrawDestroy(i, g_NextTD[i]);
            PlayerTextDrawDestroy(i, g_PageInfoTD[i]);
            PlayerTextDrawDestroy(i, g_MenuBackground[i]);
        }
    }
    print("ͼ�λ������˵���ж��");
    return 1;
}

public OnPlayerConnect(playerid) {
    g_MenuOpen[playerid] = 0;
    g_CurrentPage[playerid] = 0;
    CreatePlayerMenu(playerid);
    SendClientMessage(playerid, 0x00FFAAFF, "��ӭ������ /w list ��ͼ�λ������˵���");
    return 1;
}

public OnPlayerDisconnect(playerid, reason) {
    CloseWeaponMenu(playerid);
    for(new j=0; j<WEAPONS_PER_PAGE; j++) {
        PlayerTextDrawDestroy(playerid, g_WeaponTD[playerid][j]);
    }
    PlayerTextDrawDestroy(playerid, g_PrevTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_NextTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_PageInfoTD[playerid]);
    PlayerTextDrawDestroy(playerid, g_MenuBackground[playerid]);
    return 1;
}

public OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid) {
    if(!g_MenuOpen[playerid]) return 0;
    
    if(playertextid == g_PrevTD[playerid]) {
        if(g_CurrentPage[playerid] > 0) {
            g_CurrentPage[playerid]--;
            RefreshPlayerMenu(playerid);
        }
        return 1;
    }
    else if(playertextid == g_NextTD[playerid]) {
        new totalPages = (g_TotalWeapons + WEAPONS_PER_PAGE - 1) / WEAPONS_PER_PAGE;
        if(g_CurrentPage[playerid] < totalPages - 1) {
            g_CurrentPage[playerid]++;
            RefreshPlayerMenu(playerid);
        }
        return 1;
    }
    else {
        for(new i=0; i<WEAPONS_PER_PAGE; i++) {
            if(playertextid == g_WeaponTD[playerid][i]) {
                new idx = g_CurrentPage[playerid] * WEAPONS_PER_PAGE + i;
                if(idx < g_TotalWeapons) {
                    new weaponid = g_Weapons[idx][wWeaponID];
                    new ammo = g_Weapons[idx][wAmmo];
                    new name[32];
                    format(name, 32, g_Weapons[idx][wName]);
                    
                    // ���ͬ����������ѡ�������ֱ�ӻ�ã�
                    // ResetPlayerWeapons(playerid); // ȡ��ע�Ϳ������������
                    GivePlayerWeapon(playerid, weaponid, ammo);
                    
                    new msg[128];
                    format(msg, sizeof(msg), "? �ѻ������: %s ?", name);
                    SendClientMessage(playerid, 0x66FF66FF, msg);
                    CloseWeaponMenu(playerid);
                }
                break;
            }
        }
        return 1;
    }
}

public OnPlayerCancelSelectTextDraw(playerid) {
    if(g_MenuOpen[playerid]) {
        CloseWeaponMenu(playerid);
    }
    return 1;
}